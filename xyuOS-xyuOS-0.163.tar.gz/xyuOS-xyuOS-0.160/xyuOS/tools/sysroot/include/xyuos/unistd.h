#ifndef XYUOS_UNISTD_H
#define XYUOS_UNISTD_H

#include <stdint.h>
#include "syscall.h"

static inline uint64_t write(uint64_t fd, const void* buf, uint64_t len){
    return xyu_syscall3(XYU_SYS_WRITE, fd, (uint64_t)buf, len);
}

static inline uint64_t yield(void){
    return xyu_syscall0(XYU_SYS_YIELD);
}

static inline uint64_t ticks(void){
    return xyu_syscall0(XYU_SYS_TICKS);
}

static inline uint64_t _exit(uint64_t code){
    return xyu_syscall1(XYU_SYS_EXIT, code);
}

static inline uint64_t fs_count(void){
    return xyu_syscall0(XYU_SYS_FS_COUNT);
}

static inline uint64_t fs_name(uint64_t index, char* out, uint64_t cap){
    return xyu_syscall3(XYU_SYS_FS_NAME, index, (uint64_t)out, cap);
}

static inline uint64_t fs_read(const char* name, void* out, uint64_t cap){
    return xyu_syscall3(XYU_SYS_FS_READ, (uint64_t)name, (uint64_t)out, cap);
}

static inline uint64_t fs_write(const char* name, const void* data, uint64_t len){
    return xyu_syscall3(XYU_SYS_FS_WRITE, (uint64_t)name, (uint64_t)data, len);
}

#endif
