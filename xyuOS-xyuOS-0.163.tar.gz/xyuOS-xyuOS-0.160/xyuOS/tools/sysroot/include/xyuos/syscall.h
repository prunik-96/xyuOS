#ifndef XYUOS_SYSCALL_H
#define XYUOS_SYSCALL_H

#include <stdint.h>

#define XYU_SYS_PUTS   1
#define XYU_SYS_PUTI   2
#define XYU_SYS_CLS    3
#define XYU_SYS_WRITE  4
#define XYU_SYS_YIELD  24
#define XYU_SYS_TICKS  39
#define XYU_SYS_EXIT   60
#define XYU_SYS_FS_COUNT 100
#define XYU_SYS_FS_NAME  101
#define XYU_SYS_FS_READ  102
#define XYU_SYS_FS_WRITE 103

static inline uint64_t xyu_syscall0(uint64_t n){
    uint64_t r;
    __asm__ volatile("int $0x80" : "=a"(r) : "a"(n) : "memory");
    return r;
}

static inline uint64_t xyu_syscall1(uint64_t n, uint64_t a1){
    uint64_t r;
    __asm__ volatile("int $0x80" : "=a"(r) : "a"(n), "b"(a1) : "memory");
    return r;
}

static inline uint64_t xyu_syscall3(uint64_t n, uint64_t a1, uint64_t a2, uint64_t a3){
    uint64_t r;
    __asm__ volatile("int $0x80" : "=a"(r) : "a"(n), "b"(a1), "c"(a2), "d"(a3) : "memory");
    return r;
}

#endif
