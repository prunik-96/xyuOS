#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
SYSROOT_DIR="${1:-$ROOT_DIR/build64/sysroot}"

mkdir -p "$SYSROOT_DIR/usr/include/xyuos"
mkdir -p "$SYSROOT_DIR/usr/lib"

cp "$ROOT_DIR/tools/sysroot/include/xyuos/syscall.h" "$SYSROOT_DIR/usr/include/xyuos/syscall.h"
cp "$ROOT_DIR/tools/sysroot/include/xyuos/unistd.h" "$SYSROOT_DIR/usr/include/xyuos/unistd.h"

# Keep compatibility include for existing samples
cp "$ROOT_DIR/tools/user64/sys.h" "$SYSROOT_DIR/usr/include/xyuos/sys.h"

# Build startup object into sysroot
nasm -f elf64 "$ROOT_DIR/tools/user64/crt0.s" -o "$SYSROOT_DIR/usr/lib/crt0.o"

cat > "$SYSROOT_DIR/usr/lib/xyu_user64.ld" << 'LD'
ENTRY(_start)
SECTIONS {
  . = 0x200000;
  .text : { *(.text*) }
  .rodata : { *(.rodata*) }
  .data : { *(.data*) }
  .bss : { *(.bss*) *(COMMON) }
}
LD

echo "Prepared sysroot: $SYSROOT_DIR"
