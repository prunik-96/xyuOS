#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
WORK_DIR="${ROOT_DIR}/build64/toolchain"
PREFIX_DIR="${ROOT_DIR}/toolchain/x86_64-elf"
TARGET="x86_64-elf"
JOBS="${JOBS:-$(nproc)}"
BINUTILS_VER="2.43"
GCC_VER="14.2.0"

mkdir -p "$WORK_DIR" "$PREFIX_DIR"
cd "$WORK_DIR"

fetch() {
  local url="$1"
  local out="$2"
  if [[ ! -f "$out" ]]; then
    curl -L "$url" -o "$out"
  fi
}

fetch "https://ftp.gnu.org/gnu/binutils/binutils-${BINUTILS_VER}.tar.xz" "binutils-${BINUTILS_VER}.tar.xz"
fetch "https://ftp.gnu.org/gnu/gcc/gcc-${GCC_VER}/gcc-${GCC_VER}.tar.xz" "gcc-${GCC_VER}.tar.xz"

[[ -d "binutils-${BINUTILS_VER}" ]] || tar -xf "binutils-${BINUTILS_VER}.tar.xz"
[[ -d "gcc-${GCC_VER}" ]] || tar -xf "gcc-${GCC_VER}.tar.xz"

mkdir -p build-binutils
pushd build-binutils >/dev/null
"../binutils-${BINUTILS_VER}/configure" \
  --target="$TARGET" \
  --prefix="$PREFIX_DIR" \
  --with-sysroot \
  --disable-nls \
  --disable-werror
make -j"$JOBS"
make install
popd >/dev/null

mkdir -p build-gcc
pushd build-gcc >/dev/null
"../gcc-${GCC_VER}/configure" \
  --target="$TARGET" \
  --prefix="$PREFIX_DIR" \
  --disable-nls \
  --enable-languages=c \
  --without-headers \
  --disable-shared \
  --disable-threads \
  --disable-libssp \
  --disable-libquadmath \
  --disable-libgomp \
  --disable-libatomic \
  --disable-libstdcxx
make -j"$JOBS" all-gcc
make -j"$JOBS" all-target-libgcc
make install-gcc
make install-target-libgcc
popd >/dev/null

echo "Toolchain installed: ${PREFIX_DIR}"
echo "Use: ${PREFIX_DIR}/bin/${TARGET}-gcc"
