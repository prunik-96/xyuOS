#ifndef XYUOS_USER64_SYS_H
#define XYUOS_USER64_SYS_H

#include <stdint.h>
#include <stddef.h>

static inline uint64_t sys_call0(uint64_t n){
    uint64_t r;
    __asm__ volatile("int $0x80" : "=a"(r) : "a"(n) : "memory");
    return r;
}

static inline uint64_t sys_call1(uint64_t n, uint64_t a1){
    uint64_t r;
    __asm__ volatile("int $0x80" : "=a"(r) : "a"(n), "b"(a1) : "memory");
    return r;
}

static inline uint64_t sys_call3(uint64_t n, uint64_t a1, uint64_t a2, uint64_t a3){
    uint64_t r;
    __asm__ volatile("int $0x80" : "=a"(r) : "a"(n), "b"(a1), "c"(a2), "d"(a3) : "memory");
    return r;
}

static inline uint64_t sys_write(uint64_t fd, const void* buf, uint64_t len){
    return sys_call3(4, fd, (uint64_t)buf, len);
}

static inline uint64_t sys_puts(const char* s){
    return sys_call1(1, (uint64_t)s);
}

static inline uint64_t sys_puti(uint64_t n){
    return sys_call1(2, n);
}

static inline uint64_t sys_cls(void){
    return sys_call0(3);
}

static inline uint64_t sys_yield(void){
    return sys_call0(24);
}

static inline uint64_t sys_ticks(void){
    return sys_call0(39);
}

static inline uint64_t sys_fs_count(void){
    return sys_call0(100);
}

static inline uint64_t sys_fs_name(uint64_t index, char* out, uint64_t out_cap){
    return sys_call3(101, index, (uint64_t)out, out_cap);
}

static inline uint64_t sys_fs_read(const char* name, void* out, uint64_t out_cap){
    return sys_call3(102, (uint64_t)name, (uint64_t)out, out_cap);
}

static inline uint64_t sys_fs_write(const char* name, const void* data, uint64_t len){
    return sys_call3(103, (uint64_t)name, (uint64_t)data, len);
}

static inline uint64_t sys_exit(uint64_t code){
    return sys_call1(60, code);
}

static inline uint64_t mini_strlen(const char* s){
    uint64_t n = 0;
    while(s && s[n]) n++;
    return n;
}

#endif
