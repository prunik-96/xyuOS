BITS 64
GLOBAL _start

SECTION .text
_start:
    mov rax, 4
    mov rbx, 1
    mov rcx, msg
    mov rdx, msg_len
    int 0x80

    mov rax, 39
    int 0x80
    mov rbx, rax

    mov rax, 2
    int 0x80

    mov rax, 4
    mov rbx, 1
    mov rcx, nl
    mov rdx, 1
    int 0x80

    mov rax, 60
    xor rbx, rbx
    int 0x80

.hang:
    hlt
    jmp .hang

SECTION .rodata
msg db 'hello from user64 ASM pipeline', 10, 0
msg_len equ $ - msg - 1
nl db 10
