#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 3 ]]; then
  echo "Usage: $0 <chunks-dir> <prefix> <disk.img> [manifest_lba] [start_lba]"
  echo "Example: $0 build64/user_chunks u64 disk.img 90 200"
  exit 1
fi

CHUNKS_DIR="$1"
PREFIX="$2"
DISK_IMG="$3"
MANIFEST_LBA="${4:-90}"
START_LBA="${5:-200}"

if [[ ! -d "$CHUNKS_DIR" ]]; then
  echo "Chunks dir not found: $CHUNKS_DIR"
  exit 1
fi

python3 - "$CHUNKS_DIR" "$PREFIX" "$DISK_IMG" "$MANIFEST_LBA" "$START_LBA" << 'PY'
import pathlib, re, struct, sys
chunks_dir = pathlib.Path(sys.argv[1])
prefix = sys.argv[2]
disk = pathlib.Path(sys.argv[3])
manifest_lba = int(sys.argv[4])
start_lba = int(sys.argv[5])

pat = re.compile(rf"^{re.escape(prefix)}\.(\d+)$")
parts = []
for p in chunks_dir.iterdir():
    m = pat.match(p.name)
    if m:
        parts.append((int(m.group(1)), p))
if not parts:
    raise SystemExit(f"No chunk files found for prefix '{prefix}'")
parts.sort(key=lambda x: x[0])

expected = 0
blob = bytearray()
for idx, p in parts:
    if idx != expected:
        raise SystemExit(f"Missing chunk index {expected}, found {idx}")
    blob.extend(p.read_bytes())
    expected += 1

chunk_count = len(parts)
total_size = len(blob)

# Ensure disk exists and large enough
need_bytes = (start_lba + chunk_count) * 512
if not disk.exists():
    disk.write_bytes(b"\x00" * need_bytes)
else:
    cur = disk.stat().st_size
    if cur < need_bytes:
        with disk.open("ab") as f:
            f.write(b"\x00" * (need_bytes - cur))

with disk.open("r+b") as f:
    for i, (_, p) in enumerate(parts):
        data = p.read_bytes()
        if len(data) > 512:
            raise SystemExit(f"Chunk too big (>512): {p}")
        data = data + b"\x00" * (512 - len(data))
        f.seek((start_lba + i) * 512)
        f.write(data)

    prefix_bytes = prefix.encode("ascii", errors="ignore")[:12]
    prefix_bytes = prefix_bytes + b"\x00" * (12 - len(prefix_bytes))
    manifest = bytearray(512)
    manifest[0:4] = b"U64M"
    manifest[4:16] = prefix_bytes
    manifest[16:20] = struct.pack("<I", chunk_count)
    manifest[20:24] = struct.pack("<I", total_size)
    manifest[24:28] = struct.pack("<I", start_lba)

    f.seek(manifest_lba * 512)
    f.write(manifest)

print(f"Injected prefix={prefix} chunks={chunk_count} size={total_size} into {disk}")
print(f"Manifest LBA={manifest_lba}, data start LBA={start_lba}")
PY
