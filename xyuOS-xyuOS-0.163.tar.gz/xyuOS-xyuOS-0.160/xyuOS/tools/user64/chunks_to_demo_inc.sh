#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 4 ]]; then
  echo "Usage: $0 <chunks-dir> <prefix> <symbol> <out-inc>"
  echo "Example: $0 /tmp/u64_chunks u64 user64_demo_elf src/kernel/user64_demo_elf.inc"
  exit 1
fi

CHUNKS_DIR="$1"
PREFIX="$2"
SYMBOL="$3"
OUT_INC="$4"

if [[ ! -d "$CHUNKS_DIR" ]]; then
  echo "Chunks dir not found: $CHUNKS_DIR"
  exit 1
fi

TMP_DIR="$(mktemp -d)"
cleanup(){ rm -rf "$TMP_DIR"; }
trap cleanup EXIT

python3 - "$CHUNKS_DIR" "$PREFIX" "$TMP_DIR/merged.elf" << 'PY'
import pathlib, re, sys
chunks_dir = pathlib.Path(sys.argv[1])
prefix = sys.argv[2]
out = pathlib.Path(sys.argv[3])
pat = re.compile(rf"^{re.escape(prefix)}\.(\d+)$")
parts = []
for p in chunks_dir.iterdir():
    m = pat.match(p.name)
    if m:
        parts.append((int(m.group(1)), p))
if not parts:
    raise SystemExit(f"No chunk files found for prefix '{prefix}' in {chunks_dir}")
parts.sort(key=lambda x: x[0])
expected = 0
blob = bytearray()
for idx, p in parts:
    if idx != expected:
        raise SystemExit(f"Missing chunk index {expected} (found {idx})")
    blob.extend(p.read_bytes())
    expected += 1
out.write_bytes(blob)
print(f"Merged ELF size: {len(blob)} bytes")
PY

xxd -i "$TMP_DIR/merged.elf" > "$TMP_DIR/raw.inc"
sed -E \
  -e "s/^unsigned char [^\[]+/unsigned char ${SYMBOL}/" \
  -e "s/^unsigned int [^ ]+/unsigned int ${SYMBOL}_len/" \
  "$TMP_DIR/raw.inc" > "$OUT_INC"

echo "Updated include: $OUT_INC"
