#include "sys.h"

int main(void){
    const char* msg = "hello from user64 C runtime\n";
    sys_write(1, msg, mini_strlen(msg));

    sys_puts("ticks: ");
    sys_puti(sys_ticks());
    sys_puts("\n");

    return 7;
}
