#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 3 ]]; then
  echo "Usage: $0 <source.c|source.asm> <prefix> <out-dir>"
  echo "Example: $0 tools/user64/sample_asm_app.asm u64 /tmp/u64_chunks"
  exit 1
fi

SRC="$1"
PREFIX="$2"
OUTDIR="$3"

if [[ ! -f "$SRC" ]]; then
  if [[ "${SRC: -1}" == "~" ]]; then
    SRC_NO_TILDE="${SRC%?}"
    if [[ -f "$SRC_NO_TILDE" ]]; then
      echo "Warning: source '$SRC' not found, using '$SRC_NO_TILDE'"
      SRC="$SRC_NO_TILDE"
    fi
  fi
fi

if [[ ! -f "$SRC" ]]; then
  echo "Source not found: $SRC"
  exit 1
fi

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
CRT0="$ROOT_DIR/tools/user64/crt0.s"
INCLUDE_DIR="$ROOT_DIR/tools/user64"
SYSROOT_DIR="${XYU_SYSROOT:-$ROOT_DIR/build64/sysroot}"

TOOLCHAIN_PREFIX="${XYU_TOOLCHAIN_PREFIX:-$ROOT_DIR/toolchain/x86_64-elf/bin/x86_64-elf-}"

CC_CMD="${TOOLCHAIN_PREFIX}gcc"
LD_CMD="${TOOLCHAIN_PREFIX}ld"

if ! command -v "$CC_CMD" >/dev/null 2>&1 || ! command -v "$LD_CMD" >/dev/null 2>&1; then
  if command -v x86_64-linux-gnu-gcc >/dev/null 2>&1 && command -v x86_64-linux-gnu-ld >/dev/null 2>&1; then
    CC_CMD="x86_64-linux-gnu-gcc"
    LD_CMD="x86_64-linux-gnu-ld"
  else
    echo "No suitable compiler found."
    echo "Build cross toolchain first: tools/toolchain/build_x86_64_elf.sh"
    exit 1
  fi
fi

TMP_DIR="$(mktemp -d)"
cleanup(){ rm -rf "$TMP_DIR"; }
trap cleanup EXIT

CRT0_OBJ="$TMP_DIR/crt0.o"
APP_OBJ="$TMP_DIR/app.o"
APP_ELF="$TMP_DIR/app.elf"
LINKER_SCRIPT=""

if [[ -f "$SYSROOT_DIR/usr/lib/crt0.o" ]]; then
  CRT0_OBJ="$SYSROOT_DIR/usr/lib/crt0.o"
else
  nasm -f elf64 "$CRT0" -o "$CRT0_OBJ"
fi

if [[ -f "$SYSROOT_DIR/usr/lib/xyu_user64.ld" ]]; then
  LINKER_SCRIPT="$SYSROOT_DIR/usr/lib/xyu_user64.ld"
fi

INC_FLAGS=( -I"$INCLUDE_DIR" )
if [[ -d "$SYSROOT_DIR/usr/include" ]]; then
  INC_FLAGS+=( -isystem "$SYSROOT_DIR/usr/include" )
fi

case "$SRC" in
  *.asm)
    nasm -f elf64 "$SRC" -o "$APP_OBJ"
    CRT0_OBJ=""
    ;;
  *.c)
    "$CC_CMD" -ffreestanding -fno-pic -fno-pie -fno-stack-protector \
      -nostdlib -nostartfiles -nodefaultlibs -O2 -Wall -Wextra \
      "${INC_FLAGS[@]}" -c "$SRC" -o "$APP_OBJ"
    ;;
  *)
    echo "Unsupported source type: $SRC"
    exit 1
    ;;
esac

if [[ -n "$LINKER_SCRIPT" ]]; then
  if [[ -n "$CRT0_OBJ" ]]; then
    "$LD_CMD" -m elf_x86_64 -nostdlib -N -T "$LINKER_SCRIPT" -e _start \
      -o "$APP_ELF" "$CRT0_OBJ" "$APP_OBJ"
  else
    "$LD_CMD" -m elf_x86_64 -nostdlib -N -T "$LINKER_SCRIPT" -e _start \
      -o "$APP_ELF" "$APP_OBJ"
  fi
else
  if [[ -n "$CRT0_OBJ" ]]; then
    "$LD_CMD" -m elf_x86_64 -nostdlib -N -Ttext 0x200000 -e _start \
      -o "$APP_ELF" "$CRT0_OBJ" "$APP_OBJ"
  else
    "$LD_CMD" -m elf_x86_64 -nostdlib -N -Ttext 0x200000 -e _start \
      -o "$APP_ELF" "$APP_OBJ"
  fi
fi

mkdir -p "$OUTDIR"

python3 - "$APP_ELF" "$PREFIX" "$OUTDIR" << 'PY'
import pathlib, sys
elf = pathlib.Path(sys.argv[1]).read_bytes()
prefix = sys.argv[2]
out = pathlib.Path(sys.argv[3])
out.mkdir(parents=True, exist_ok=True)

# Remove stale chunks for this prefix
for p in out.glob(f"{prefix}.*"):
  if p.is_file():
    p.unlink()

chunk_size = 512
for i in range(0, len(elf), chunk_size):
    chunk = elf[i:i+chunk_size]
    p = out / f"{prefix}.{i//chunk_size}"
    p.write_bytes(chunk)
print(f"ELF size: {len(elf)} bytes")
print(f"Chunks: {(len(elf) + chunk_size - 1)//chunk_size}")
print(f"Output: {out}")
PY
