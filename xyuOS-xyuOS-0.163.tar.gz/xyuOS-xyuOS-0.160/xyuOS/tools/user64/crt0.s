BITS 64
GLOBAL _start
EXTERN main

SECTION .text
_start:
    call main

    mov rbx, rax
    mov rax, 60
    int 0x80

.hang:
    hlt
    jmp .hang
