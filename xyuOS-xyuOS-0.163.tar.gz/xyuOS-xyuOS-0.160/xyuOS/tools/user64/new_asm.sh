#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <name>"
  echo "Example: $0 hello"
  exit 1
fi

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
NAME="$1"
OUT_DIR="$ROOT_DIR/user64"
OUT_FILE="$OUT_DIR/${NAME}.asm"
TEMPLATE="$ROOT_DIR/tools/user64/template.asm"

mkdir -p "$OUT_DIR"

if [[ -e "$OUT_FILE" ]]; then
  echo "File already exists: $OUT_FILE"
  exit 1
fi

cp "$TEMPLATE" "$OUT_FILE"

echo "Created: $OUT_FILE"
