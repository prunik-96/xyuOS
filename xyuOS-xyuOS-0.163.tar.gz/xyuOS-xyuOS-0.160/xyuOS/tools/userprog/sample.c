#include "user_api.h"

void _start(void){
    sys_puts("hello from real c\n");
    sys_puti(2026);
    sys_puts("\n");
}
