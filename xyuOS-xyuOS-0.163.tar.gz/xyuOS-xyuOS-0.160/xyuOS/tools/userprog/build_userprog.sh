#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 2 ]]; then
  echo "Usage: $0 <source.c|source.asm> <out.bin.txt>"
  exit 1
fi

SRC="$1"
OUT="$2"

if [[ ! -f "$SRC" ]]; then
  echo "Source not found: $SRC"
  exit 1
fi

TMP_DIR="$(mktemp -d)"
cleanup(){ rm -rf "$TMP_DIR"; }
trap cleanup EXIT

OBJ="$TMP_DIR/prog.o"
ELF="$TMP_DIR/prog.elf"
BIN="$TMP_DIR/prog.bin"

case "$SRC" in
  *.asm)
    nasm -f elf32 "$SRC" -o "$OBJ"
    ;;
  *.c)
    gcc -m32 -ffreestanding -fno-pic -fno-pie -fno-stack-protector \
      -nostdlib -nostartfiles -nodefaultlibs -O2 -Wall -Wextra \
      -fno-asynchronous-unwind-tables -fno-unwind-tables \
      -I"$(dirname "$0")" -c "$SRC" -o "$OBJ"
    ;;
  *)
    echo "Unsupported source extension: $SRC"
    exit 1
    ;;
esac

ld -m elf_i386 -nostdlib -N -Ttext 0x00000000 -e _start -o "$ELF" "$OBJ"
objcopy -O binary "$ELF" "$BIN"

SIZE=$(wc -c < "$BIN")
if (( SIZE <= 0 )); then
  echo "Empty binary generated"
  exit 1
fi
if (( SIZE > 512 )); then
  echo "Program is too large for current FS file (512 bytes): ${SIZE} bytes"
  exit 1
fi

{
  echo "# xyuOS runnable .bin payload (hex bytes)"
  echo "# generated from: $SRC"
  echo "# size: ${SIZE} bytes"
  od -An -tx1 -v "$BIN" | sed 's/^ *//; s/  */ /g'
} > "$OUT"

echo "Generated: $OUT"
