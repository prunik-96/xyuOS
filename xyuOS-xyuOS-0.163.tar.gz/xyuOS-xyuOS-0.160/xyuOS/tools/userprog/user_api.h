#ifndef USER_API_H
#define USER_API_H

static inline int sys_call(int num, int arg){
    int ret;
    __asm__ volatile("int $0x80" : "=a"(ret) : "a"(num), "b"(arg));
    return ret;
}

static inline int sys_puts(const char* s){
    return sys_call(1, (int)s);
}

static inline int sys_puti(int value){
    return sys_call(2, value);
}

static inline int sys_cls(void){
    return sys_call(3, 0);
}

#endif
