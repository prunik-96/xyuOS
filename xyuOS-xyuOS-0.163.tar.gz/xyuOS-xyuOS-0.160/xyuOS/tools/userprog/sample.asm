BITS 32
GLOBAL _start

_start:
    mov eax, 1
    mov ebx, msg
    int 0x80

    mov eax, 2
    mov ebx, 12345
    int 0x80

    mov eax, 1
    mov ebx, nl
    int 0x80

    ret

msg db 'hello from real asm', 10, 0
nl  db 10, 0
