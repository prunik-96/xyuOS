BITS 64
GLOBAL _start

SECTION .text
_start:
    ; print label
    mov rax, 4
    mov rbx, 1
    mov rcx, label
    mov rdx, label_len
    int 0x80

    ; get ticks (RAX = ticks)
    mov rax, 39
    int 0x80

    ; print integer from RBX using syscall puti(2)
    mov rbx, rax
    mov rax, 2
    int 0x80

    ; newline
    mov rax, 4
    mov rbx, 1
    mov rcx, nl
    mov rdx, 1
    int 0x80

    ; exit(0)
    mov rax, 60
    xor rbx, rbx
    int 0x80

.hang:
    hlt
    jmp .hang

SECTION .rodata
label db 'ticks = '
label_len equ $ - label
nl db 10
