BITS 64
GLOBAL _start

SECTION .text
_start:
    mov rax, 4
    mov rbx, 1
    mov rcx, msg
    mov rdx, msg_len
    int 0x80

    mov rax, 60
    xor rbx, rbx
    int 0x80

.hang:
    hlt
    jmp .hang

SECTION .rodata
msg db 'hello from user64 hello.asm', 10
msg_len equ $ - msg
