#include "../tools/user64/sys.h"

int main(void){
    char name[64];
    uint64_t count = sys_fs_count();

    sys_puts("[fslist] files: ");
    sys_puti(count);
    sys_puts("\n");

    for(uint64_t i=0;i<count;i++){
        uint64_t n = sys_fs_name(i, name, sizeof(name));
        if((int64_t)n < 0) continue;
        sys_puts(" - ");
        sys_puts(name);
        sys_puts("\n");
    }

    return 0;
}
