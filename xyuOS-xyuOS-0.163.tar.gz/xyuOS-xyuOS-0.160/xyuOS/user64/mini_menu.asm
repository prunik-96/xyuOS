BITS 64
GLOBAL _start

SECTION .text
_start:
    ; cls()
    mov rax, 3
    int 0x80

    ; title
    mov rax, 4
    mov rbx, 1
    mov rcx, title
    mov rdx, title_len
    int 0x80

    ; line 1
    mov rax, 4
    mov rbx, 1
    mov rcx, item1
    mov rdx, item1_len
    int 0x80

    ; line 2
    mov rax, 4
    mov rbx, 1
    mov rcx, item2
    mov rdx, item2_len
    int 0x80

    ; line 3
    mov rax, 4
    mov rbx, 1
    mov rcx, item3
    mov rdx, item3_len
    int 0x80

    ; prompt
    mov rax, 4
    mov rbx, 1
    mov rcx, prompt
    mov rdx, prompt_len
    int 0x80

    ; demo output: current ticks
    mov rax, 39
    int 0x80
    mov rbx, rax
    mov rax, 2
    int 0x80

    mov rax, 4
    mov rbx, 1
    mov rcx, nl
    mov rdx, 1
    int 0x80

    ; exit(0)
    mov rax, 60
    xor rbx, rbx
    int 0x80

.hang:
    hlt
    jmp .hang

SECTION .rodata
title db '=== MINI MENU ===', 10
title_len equ $ - title
item1 db '1) Hello', 10
item1_len equ $ - item1
item2 db '2) Show ticks', 10
item2_len equ $ - item2
item3 db '3) Exit', 10
item3_len equ $ - item3
prompt db 'Auto choice: show ticks -> '
prompt_len equ $ - prompt
nl db 10
