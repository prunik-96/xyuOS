#pragma once
#include <stdint.h>

typedef struct {
  uint64_t entry;
  uint64_t low_vaddr;
  uint64_t high_vaddr;
  uint16_t phnum;
} elf64_info_t;

int elf64_validate(const uint8_t* image, uint64_t image_size, elf64_info_t* out_info);
int elf64_load_pt_load_segments(
    const uint8_t* image,
    uint64_t image_size,
    uint8_t* dst_memory,
    uint64_t dst_memory_size,
    uint64_t map_base_vaddr,
    uint64_t* out_entry_offset
);
