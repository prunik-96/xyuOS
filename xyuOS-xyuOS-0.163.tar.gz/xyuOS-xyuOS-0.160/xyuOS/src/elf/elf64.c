#include "elf64.h"

#define PT_LOAD 1
#define ET_EXEC 2
#define ET_DYN  3
#define EM_X86_64 62

typedef struct {
  unsigned char e_ident[16];
  uint16_t e_type;
  uint16_t e_machine;
  uint32_t e_version;
  uint64_t e_entry;
  uint64_t e_phoff;
  uint64_t e_shoff;
  uint32_t e_flags;
  uint16_t e_ehsize;
  uint16_t e_phentsize;
  uint16_t e_phnum;
  uint16_t e_shentsize;
  uint16_t e_shnum;
  uint16_t e_shstrndx;
} __attribute__((packed)) elf64_ehdr_t;

typedef struct {
  uint32_t p_type;
  uint32_t p_flags;
  uint64_t p_offset;
  uint64_t p_vaddr;
  uint64_t p_paddr;
  uint64_t p_filesz;
  uint64_t p_memsz;
  uint64_t p_align;
} __attribute__((packed)) elf64_phdr_t;

static int minmax_vaddr(const uint8_t* image, uint64_t size, const elf64_ehdr_t* eh, uint64_t* low, uint64_t* high){
  uint64_t l = (uint64_t)-1;
  uint64_t h = 0;
  int seen = 0;

  for(uint16_t i=0;i<eh->e_phnum;i++){
    uint64_t off = eh->e_phoff + (uint64_t)i * eh->e_phentsize;
    if(off + sizeof(elf64_phdr_t) > size) return 0;

    const elf64_phdr_t* ph = (const elf64_phdr_t*)(image + off);
    if(ph->p_type != PT_LOAD) continue;
    if(ph->p_filesz > ph->p_memsz) return 0;
    if(ph->p_offset + ph->p_filesz > size) return 0;

    if(!seen || ph->p_vaddr < l) l = ph->p_vaddr;
    uint64_t end = ph->p_vaddr + ph->p_memsz;
    if(!seen || end > h) h = end;
    seen = 1;
  }

  if(!seen) return 0;
  *low = l;
  *high = h;
  return 1;
}

int elf64_validate(const uint8_t* image, uint64_t image_size, elf64_info_t* out_info){
  if(!image || image_size < sizeof(elf64_ehdr_t) || !out_info) return 0;

  const elf64_ehdr_t* eh = (const elf64_ehdr_t*)image;

  if(eh->e_ident[0] != 0x7F || eh->e_ident[1] != 'E' || eh->e_ident[2] != 'L' || eh->e_ident[3] != 'F') return 0;
  if(eh->e_ident[4] != 2) return 0; // ELFCLASS64
  if(eh->e_ident[5] != 1) return 0; // little-endian
  if(eh->e_machine != EM_X86_64) return 0;
  if(eh->e_type != ET_EXEC && eh->e_type != ET_DYN) return 0;
  if(eh->e_phentsize < sizeof(elf64_phdr_t)) return 0;
  if(eh->e_phnum == 0) return 0;
  if(eh->e_phoff >= image_size) return 0;

  uint64_t low = 0, high = 0;
  if(!minmax_vaddr(image, image_size, eh, &low, &high)) return 0;

  out_info->entry = eh->e_entry;
  out_info->low_vaddr = low;
  out_info->high_vaddr = high;
  out_info->phnum = eh->e_phnum;
  return 1;
}

static void memzero8(uint8_t* p, uint64_t n){
  for(uint64_t i=0;i<n;i++) p[i] = 0;
}

static void memcpy8(uint8_t* d, const uint8_t* s, uint64_t n){
  for(uint64_t i=0;i<n;i++) d[i] = s[i];
}

int elf64_load_pt_load_segments(
    const uint8_t* image,
    uint64_t image_size,
    uint8_t* dst_memory,
    uint64_t dst_memory_size,
    uint64_t map_base_vaddr,
    uint64_t* out_entry_offset
){
  elf64_info_t info;
  if(!elf64_validate(image, image_size, &info)) return 0;

  const elf64_ehdr_t* eh = (const elf64_ehdr_t*)image;
  uint64_t span = info.high_vaddr - map_base_vaddr;
  if(info.low_vaddr < map_base_vaddr) return 0;
  if(span > dst_memory_size) return 0;

  for(uint16_t i=0;i<eh->e_phnum;i++){
    uint64_t off = eh->e_phoff + (uint64_t)i * eh->e_phentsize;
    const elf64_phdr_t* ph = (const elf64_phdr_t*)(image + off);

    if(ph->p_type != PT_LOAD) continue;

    if(ph->p_vaddr < map_base_vaddr) return 0;
    uint64_t seg_off = ph->p_vaddr - map_base_vaddr;
    if(seg_off + ph->p_memsz > dst_memory_size) return 0;
    if(ph->p_offset + ph->p_filesz > image_size) return 0;

    memcpy8(dst_memory + seg_off, image + ph->p_offset, ph->p_filesz);
    if(ph->p_memsz > ph->p_filesz){
      memzero8(dst_memory + seg_off + ph->p_filesz, ph->p_memsz - ph->p_filesz);
    }
  }

  if(info.entry < map_base_vaddr) return 0;
  *out_entry_offset = info.entry - map_base_vaddr;
  return 1;
}
