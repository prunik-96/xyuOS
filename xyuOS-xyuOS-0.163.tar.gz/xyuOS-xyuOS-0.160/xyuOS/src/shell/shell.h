#ifndef SHELL_H
#define SHELL_H

void shell_init();
void shell_handle_command(char* cmd);

#endif
