#include <stdint.h>
#include "../cpu/idt64.h"
#include "../elf/elf64.h"
#include "../drivers/ata.h"
#include "../drivers/ports.h"
#include "../fs/fs.h"
#include "../util/string.h"
#include "user64_demo_elf.inc"

extern void enter_user_mode64(uint64_t rip, uint64_t rsp);

static volatile uint16_t* const VGA = (uint16_t*)0xB8000;
static int cursor = 0;
static uint8_t elf64_image_mem[8 * 1024];
static uint8_t user_stack[4096];
static char boot_user_prefix_buf[32] = "u64";
static const char* boot_user_prefix = "u64";
static file_t* shell_cur_file = 0;

static int run_elf64_from_fs_prefix(const char* prefix);
static int run_elf64_from_disk_manifest(const char* prefix);

#define USER64_MANIFEST_SECTOR 90

static void putc64(char c, uint8_t color){
    if(c == '\n'){
        int row = cursor / 80;
        cursor = (row + 1) * 80;
        return;
    }
    if(cursor >= 80 * 25) cursor = 0;
    VGA[cursor++] = ((uint16_t)color << 8) | (uint8_t)c;
}

static void print64(const char* s, uint8_t color){
    for(int i=0; s[i]; i++) putc64(s[i], color);
}

static void print64_dec(int v, uint8_t color){
    if(v == 0){ putc64('0', color); return; }
    if(v < 0){ putc64('-', color); v = -v; }
    char b[16];
    int i = 0;
    while(v && i < (int)sizeof(b)){
        b[i++] = (char)('0' + (v % 10));
        v /= 10;
    }
    while(i--) putc64(b[i], color);
}

static void clear64(uint8_t color){
    for(int i=0;i<80*25;i++) VGA[i] = ((uint16_t)color << 8) | ' ';
    cursor = 0;
}

static void backspace64(uint8_t color){
    if(cursor <= 0) return;
    cursor--;
    VGA[cursor] = ((uint16_t)color << 8) | ' ';
}

enum {
    SYS64_PUTS = 1,
    SYS64_WRITE = 4,
    SYS64_PUTI = 2,
    SYS64_CLS  = 3,
    SYS64_YIELD = 24,
    SYS64_TICKS = 39,
    SYS64_EXIT = 60,
    SYS64_FS_COUNT = 100,
    SYS64_FS_NAME  = 101,
    SYS64_FS_READ  = 102,
    SYS64_FS_WRITE = 103
};

static uint64_t rdtsc64(void){
    uint32_t lo = 0, hi = 0;
    __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32) | lo;
}

static void print64_n(const char* s, uint64_t n, uint8_t color){
    if(!s) return;
    for(uint64_t i=0;i<n;i++) putc64(s[i], color);
}

static uint32_t rd_le32(const uint8_t* p){
    return (uint32_t)p[0]
        | ((uint32_t)p[1] << 8)
        | ((uint32_t)p[2] << 16)
        | ((uint32_t)p[3] << 24);
}

static void print_u64(uint64_t v, uint8_t color){
    if(v == 0){ putc64('0', color); return; }
    char b[24];
    int i = 0;
    while(v && i < (int)sizeof(b)){
        b[i++] = (char)('0' + (v % 10));
        v /= 10;
    }
    while(i--) putc64(b[i], color);
}

static int copy_cstr_from_user(char* dst, int dst_max, const char* src){
    if(!dst || !src || dst_max <= 0) return 0;
    int i = 0;
    for(; i < dst_max - 1; i++){
        char c = src[i];
        dst[i] = c;
        if(c == 0) return 1;
    }
    dst[dst_max - 1] = 0;
    return 0;
}

static uint64_t sys64_fs_name(uint64_t idx, char* out, uint64_t out_cap){
    if(!out || out_cap < 2) return (uint64_t)-1;
    file_t* f = fs_at((int)idx);
    if(!f) return (uint64_t)-1;

    uint64_t n = (uint64_t)kstrlen(f->name);
    if(n + 1 > out_cap) return (uint64_t)-1;
    for(uint64_t i=0;i<=n;i++) out[i] = f->name[i];
    return n;
}

static uint64_t sys64_fs_read(const char* name_user, char* out, uint64_t out_cap){
    if(!name_user || !out || out_cap == 0) return (uint64_t)-1;

    char name[MAX_FILENAME];
    if(!copy_cstr_from_user(name, (int)sizeof(name), name_user)) return (uint64_t)-1;

    file_t* f = fs_get(name);
    if(!f) return (uint64_t)-1;

    ata_read_sector(f->sector, (uint8_t*)f->data);
    int size = f->size;
    if(size < 0) size = 0;
    if((uint64_t)size > out_cap) size = (int)out_cap;

    for(int i=0;i<size;i++) out[i] = f->data[i];
    return (uint64_t)size;
}

static uint64_t sys64_fs_write(const char* name_user, const char* in, uint64_t len){
    if(!name_user || !in) return (uint64_t)-1;

    char name[MAX_FILENAME];
    if(!copy_cstr_from_user(name, (int)sizeof(name), name_user)) return (uint64_t)-1;

    file_t* f = fs_get(name);
    if(!f) f = fs_create(name);
    if(!f) return (uint64_t)-1;

    if(len > MAX_FILE_SIZE) len = MAX_FILE_SIZE;
    for(uint64_t i=0;i<len;i++) f->data[i] = in[i];
    if(len < MAX_FILE_SIZE) f->data[len] = 0;
    f->size = (int)len;
    ata_write_sector(f->sector, (const uint8_t*)f->data);
    return len;
}

static const char* skip_ws64(const char* p){
    while(*p==' ' || *p=='\t' || *p=='\r' || *p=='\n') p++;
    return p;
}

static int str_ends_with64(const char* s, const char* suf){
    int ns = (int)kstrlen(s);
    int nt = (int)kstrlen(suf);
    if(nt > ns) return 0;
    return kstrcmp(s + ns - nt, suf) == 0;
}

static void disk_load64(file_t* f){
    if(!f) return;
    ata_read_sector(f->sector, (uint8_t*)f->data);
    f->data[MAX_FILE_SIZE - 1] = 0;
    f->size = (int)kstrlen(f->data);
}

static void disk_save64(file_t* f){
    if(!f) return;
    ata_write_sector(f->sector, (const uint8_t*)f->data);
}

static int shell_shift = 0;

static int kbd_poll_char64(char* out){
    static const char map_nomod[128] = {
      0,27,'1','2','3','4','5','6','7','8','9','0','-','=',8,
      9,'q','w','e','r','t','y','u','i','o','p','[',']','\n',0,
      'a','s','d','f','g','h','j','k','l',';','\'','`',0,'\\',
      'z','x','c','v','b','n','m',',','.','/',0,'*',0,' ',
    };
    static const char map_shift[128] = {
      0,27,'!','@','#','$','%','^','&','*','(',')','_','+',8,
      9,'Q','W','E','R','T','Y','U','I','O','P','{','}','\n',0,
      'A','S','D','F','G','H','J','K','L',':','"','~',0,'|',
      'Z','X','C','V','B','N','M','<','>','?',0,'*',0,' ',
    };

    if(!(inb(0x64) & 1)) return 0;
    uint8_t sc = inb(0x60);

    if(sc == 0xE0) return 0;

    int release = (sc & 0x80) != 0;
    uint8_t code = sc & 0x7F;

    if(code == 42 || code == 54){
        shell_shift = !release;
        return 0;
    }

    if(release) return 0;

    if(code == 28){ *out = '\n'; return 1; }
    if(code == 14){ *out = '\b'; return 1; }

    char c = shell_shift ? map_shift[code] : map_nomod[code];
    if(!c) return 0;
    *out = c;
    return 1;
}

static char kbd_read_char64(void){
    char c = 0;
    for(;;){
        if(kbd_poll_char64(&c)) return c;
    }
}

static void shell_readline64(char* out, int max){
    int n = 0;
    print64("$ ", 0x1F);

    for(;;){
        char c = kbd_read_char64();
        if(c == '\n'){
            putc64('\n', 0x1F);
            break;
        }
        if(c == '\b'){
            if(n > 0){
                n--;
                backspace64(0x1F);
            }
            continue;
        }
        if(c >= 32 && c <= 126 && n < max - 1){
            out[n++] = c;
            putc64(c, 0x1F);
        }
    }
    out[n] = 0;
}

static void editor_draw64(const char* name, const char* buf, int len){
    clear64(0x1F);
    print64("xyuOS64 editor: ", 0x1E);
    print64(name ? name : "(unnamed)", 0x1A);
    print64("\n", 0x1F);
    print64("ESC = exit (save prompt), typing = append mode\n", 0x1E);
    print64("----------------------------------------------\n", 0x1F);
    for(int i=0;i<len;i++){
        char c = buf[i];
        if(c == '\n' || c == '\t' || (c >= 32 && c <= 126)) putc64(c, 0x1F);
        else putc64('.', 0x1F);
    }
}

static void editor_open64(file_t* f){
    if(!f) return;

    disk_load64(f);

    char buf[MAX_FILE_SIZE];
    int len = f->size;
    if(len < 0) len = 0;
    if(len > MAX_FILE_SIZE - 1) len = MAX_FILE_SIZE - 1;

    for(int i=0;i<len;i++) buf[i] = f->data[i];
    buf[len] = 0;

    for(;;){
        editor_draw64(f->name, buf, len);
        char c = kbd_read_char64();

        if((uint8_t)c == 27){
            print64("\nSave changes? (y/n): ", 0x1E);
            char a = kbd_read_char64();
            if(a == 'y' || a == 'Y'){
                for(int i=0;i<len;i++) f->data[i] = buf[i];
                if(len < MAX_FILE_SIZE) f->data[len] = 0;
                f->size = len;
                disk_save64(f);
                print64("\nSaved. Press any key...", 0x1A);
            } else {
                print64("\nDiscarded. Press any key...", 0x4F);
            }
            (void)kbd_read_char64();
            clear64(0x1F);
            return;
        }

        if(c == '\b'){
            if(len > 0){
                len--;
                buf[len] = 0;
            }
            continue;
        }

        if(c == '\n'){
            if(len < MAX_FILE_SIZE - 1){
                buf[len++] = '\n';
                buf[len] = 0;
            }
            continue;
        }

        if(c >= 32 && c <= 126){
            if(len < MAX_FILE_SIZE - 1){
                buf[len++] = c;
                buf[len] = 0;
            }
        }
    }
}

static int run_user_prefix64(const char* prefix){
    if(run_elf64_from_disk_manifest(prefix)) return 1;
    if(run_elf64_from_fs_prefix(prefix)) return 1;
    return 0;
}

static void shell_help64(void){
    print64("help, ls, run [prefix], setprefix <p>, new <f>, open <f>, edit <f>, write <text>, save, cat <f>, clear\n", 0x1E);
    print64("note: in-OS real gcc/nasm toolchain is in progress\n", 0x1E);
}

static void shell_exec64(const char* cmd){
    cmd = skip_ws64(cmd);
    if(!*cmd) return;

    if(kstrcmp(cmd, "help") == 0){
        shell_help64();
        return;
    }

    if(kstrcmp(cmd, "clear") == 0){
        clear64(0x1F);
        return;
    }

    if(kstrcmp(cmd, "ls") == 0){
        int n = fs_count();
        for(int i=0;i<n;i++){
            file_t* f = fs_at(i);
            print64(" - ", 0x1F);
            print64(f->name, 0x1E);
            print64(" (", 0x1F);
            print64_dec(f->size, 0x1E);
            print64(")\n", 0x1F);
        }
        return;
    }

    if(kstartswith(cmd, "setprefix ")){
        const char* p = skip_ws64(cmd + 10);
        int n = 0;
        while(p[n] && p[n] != ' ' && p[n] != '\t' && n < (int)sizeof(boot_user_prefix_buf)-1){
            boot_user_prefix_buf[n] = p[n];
            n++;
        }
        boot_user_prefix_buf[n] = 0;
        if(n > 0){
            boot_user_prefix = boot_user_prefix_buf;
            print64("prefix set: ", 0x1F);
            print64(boot_user_prefix, 0x1E);
            print64("\n", 0x1F);
        }
        return;
    }

    if(kstrcmp(cmd, "run") == 0){
        if(!run_user_prefix64(boot_user_prefix)){
            print64("run failed for prefix: ", 0x4F);
            print64(boot_user_prefix, 0x4F);
            print64("\n", 0x4F);
        }
        return;
    }

    if(kstartswith(cmd, "run ")){
        const char* p = skip_ws64(cmd + 4);
        char pref[32];
        int n = 0;
        while(p[n] && p[n] != ' ' && p[n] != '\t' && n < (int)sizeof(pref)-1){
            pref[n] = p[n];
            n++;
        }
        pref[n] = 0;
        if(n == 0){
            print64("usage: run <prefix>\n", 0x4F);
            return;
        }
        if(!run_user_prefix64(pref)){
            print64("run failed for prefix: ", 0x4F);
            print64(pref, 0x4F);
            print64("\n", 0x4F);
        }
        return;
    }

    if(kstartswith(cmd, "new ")){
        const char* p = skip_ws64(cmd + 4);
        char name[MAX_FILENAME];
        int n = 0;
        while(p[n] && p[n] != ' ' && p[n] != '\t' && n < MAX_FILENAME-1){
            name[n] = p[n];
            n++;
        }
        name[n] = 0;
        if(n == 0){ print64("usage: new <file>\n", 0x4F); return; }
        file_t* f = fs_get(name);
        if(!f) f = fs_create(name);
        if(!f){ print64("new failed\n", 0x4F); return; }
        f->size = 0;
        f->data[0] = 0;
        shell_cur_file = f;
        print64("new/open: ", 0x1F);
        print64(f->name, 0x1E);
        print64("\n", 0x1F);
        return;
    }

    if(kstartswith(cmd, "open ")){
        const char* p = skip_ws64(cmd + 5);
        char name[MAX_FILENAME];
        int n = 0;
        while(p[n] && p[n] != ' ' && p[n] != '\t' && n < MAX_FILENAME-1){
            name[n] = p[n];
            n++;
        }
        name[n] = 0;
        if(n == 0){ print64("usage: open <file>\n", 0x4F); return; }
        file_t* f = fs_get(name);
        if(!f){ print64("file not found\n", 0x4F); return; }
        disk_load64(f);
        shell_cur_file = f;
        print64("opened: ", 0x1F);
        print64(f->name, 0x1E);
        print64("\n", 0x1F);
        return;
    }

    if(kstartswith(cmd, "edit ")){
        const char* p = skip_ws64(cmd + 5);
        char name[MAX_FILENAME];
        int n = 0;
        while(p[n] && p[n] != ' ' && p[n] != '\t' && n < MAX_FILENAME-1){
            name[n] = p[n];
            n++;
        }
        name[n] = 0;
        if(n == 0){ print64("usage: edit <file>\n", 0x4F); return; }
        file_t* f = fs_get(name);
        if(!f) f = fs_create(name);
        if(!f){ print64("edit failed\n", 0x4F); return; }
        shell_cur_file = f;
        editor_open64(f);
        return;
    }

    if(kstartswith(cmd, "write ")){
        if(!shell_cur_file){ print64("no open file\n", 0x4F); return; }
        const char* p = cmd + 6;
        int cur = shell_cur_file->size;
        if(cur < 0) cur = 0;
        int room = MAX_FILE_SIZE - 2 - cur;
        int i = 0;
        while(p[i] && i < room){
            shell_cur_file->data[cur + i] = p[i];
            i++;
        }
        shell_cur_file->data[cur + i] = '\n';
        shell_cur_file->data[cur + i + 1] = 0;
        shell_cur_file->size = cur + i + 1;
        print64("wrote line\n", 0x1A);
        return;
    }

    if(kstrcmp(cmd, "save") == 0){
        if(!shell_cur_file){ print64("no open file\n", 0x4F); return; }
        disk_save64(shell_cur_file);
        print64("saved\n", 0x1A);
        return;
    }

    if(kstartswith(cmd, "cat ")){
        const char* p = skip_ws64(cmd + 4);
        char name[MAX_FILENAME];
        int n = 0;
        while(p[n] && p[n] != ' ' && p[n] != '\t' && n < MAX_FILENAME-1){
            name[n] = p[n];
            n++;
        }
        name[n] = 0;
        if(n == 0){ print64("usage: cat <file>\n", 0x4F); return; }
        file_t* f = fs_get(name);
        if(!f){ print64("file not found\n", 0x4F); return; }
        disk_load64(f);
        print64(f->data, 0x1F);
        if(f->size <= 0 || !str_ends_with64(f->data, "\n")) print64("\n", 0x1F);
        return;
    }

    print64("unknown command\n", 0x4F);
}

static void shell_loop64(void){
    char line[160];
    print64("\nxyuOS64 shell ready (type help)\n", 0x1A);
    for(;;){
        shell_readline64(line, (int)sizeof(line));
        shell_exec64(line);
    }
}

void isr_exception_handler64(uint64_t vector){
    uint64_t cr2 = 0;
    __asm__ volatile("mov %%cr2, %0" : "=r"(cr2));

    print64("\n[kernel] EXCEPTION vector=", 0x4F);
    print_u64(vector, 0x4F);
    print64(" cr2=", 0x4F);
    print_u64(cr2, 0x4F);
    print64("\n", 0x4F);
}

uint64_t isr80_handler64(regs64_t* r){
    if(!r) return (uint64_t)-1;
    switch(r->rax){
        case SYS64_PUTS:
            if(r->rbx) print64((const char*)r->rbx, 0x1F);
            return 0;
        case SYS64_PUTI:
            print_u64(r->rbx, 0x1E);
            return 0;
        case SYS64_WRITE:
            if(r->rbx == 1 || r->rbx == 2){
                if(r->rcx && r->rdx){
                    print64_n((const char*)r->rcx, r->rdx, 0x1F);
                    return r->rdx;
                }
            }
            return (uint64_t)-1;
        case SYS64_CLS:
            clear64(0x1F);
            return 0;
        case SYS64_YIELD:
            __asm__ volatile("hlt");
            return 0;
        case SYS64_TICKS:
            return rdtsc64();
        case SYS64_EXIT:
            print64("[kernel] user exit code: ", 0x1E);
            print_u64(r->rbx, 0x1E);
            print64("\n", 0x1F);
            print64("[kernel] user process finished\n", 0x1A);
            for(;;){
                __asm__ volatile("hlt");
            }
        case SYS64_FS_COUNT:
            return (uint64_t)fs_count();
        case SYS64_FS_NAME:
            return sys64_fs_name(r->rbx, (char*)(uintptr_t)r->rcx, r->rdx);
        case SYS64_FS_READ:
            return sys64_fs_read((const char*)(uintptr_t)r->rbx, (char*)(uintptr_t)r->rcx, r->rdx);
        case SYS64_FS_WRITE:
            return sys64_fs_write((const char*)(uintptr_t)r->rbx, (const char*)(uintptr_t)r->rcx, r->rdx);
        default:
            return (uint64_t)-1;
    }
}

static void load_boot_prefix_from_fs(void){
    file_t* cfg = fs_get("boot64.cfg");
    if(!cfg) return;

    ata_read_sector(cfg->sector, (uint8_t*)cfg->data);

    int i = 0;
    while(i < cfg->size && (cfg->data[i]==' ' || cfg->data[i]=='\t' || cfg->data[i]=='\r' || cfg->data[i]=='\n')) i++;

    int n = 0;
    while(i < cfg->size && n < (int)sizeof(boot_user_prefix_buf)-1){
        char c = cfg->data[i];
        if(c==' ' || c=='\t' || c=='\r' || c=='\n' || c=='#') break;
        boot_user_prefix_buf[n++] = c;
        i++;
    }
    boot_user_prefix_buf[n] = 0;

    if(n > 0) boot_user_prefix = boot_user_prefix_buf;
}

static int build_chunk_name(const char* prefix, int idx, char* out, int out_max){
    if(!prefix || !out || out_max < 6 || idx < 0) return 0;

    int n = 0;
    while(prefix[n] && n < out_max - 1){
        out[n] = prefix[n];
        n++;
    }
    if(n >= out_max - 2) return 0;
    out[n++] = '.';

    char tmp[12];
    int tn = 0;
    if(idx == 0){
        tmp[tn++] = '0';
    } else {
        while(idx > 0 && tn < (int)sizeof(tmp)){
            tmp[tn++] = (char)('0' + (idx % 10));
            idx /= 10;
        }
    }

    if(n + tn >= out_max) return 0;
    while(tn--) out[n++] = tmp[tn];
    out[n] = 0;
    return 1;
}

static int write_elf_chunks_to_fs(const char* prefix, const uint8_t* image, uint64_t image_size){
    uint64_t off = 0;
    int idx = 0;

    while(off < image_size){
        char name[MAX_FILENAME];
        if(!build_chunk_name(prefix, idx, name, MAX_FILENAME)) return 0;

        file_t* f = fs_get(name);
        if(!f) f = fs_create(name);
        if(!f) return 0;

        uint64_t left = image_size - off;
        uint64_t chunk = left > MAX_FILE_SIZE ? MAX_FILE_SIZE : left;
        for(uint64_t i=0;i<chunk;i++) f->data[i] = (char)image[off+i];
        for(uint64_t i=chunk;i<MAX_FILE_SIZE;i++) f->data[i] = 0;
        f->size = (int)chunk;
        ata_write_sector(f->sector, (const uint8_t*)f->data);

        off += chunk;
        idx++;
    }

    return idx;
}

static int has_elf_chunks_in_fs(const char* prefix){
    char name[MAX_FILENAME];
    if(!build_chunk_name(prefix, 0, name, MAX_FILENAME)) return 0;
    return fs_get(name) != 0;
}

static int read_elf_chunks_from_fs(const char* prefix, uint8_t* out, uint64_t out_cap, uint64_t* out_size){
    uint64_t w = 0;
    int idx = 0;

    for(;;){
        char name[MAX_FILENAME];
        if(!build_chunk_name(prefix, idx, name, MAX_FILENAME)) return 0;

        file_t* f = fs_get(name);
        if(!f){
            if(idx == 0) return 0;
            break;
        }

        ata_read_sector(f->sector, (uint8_t*)f->data);
        if(w + (uint64_t)f->size > out_cap) return 0;
        kmemcpy(out + w, (const uint8_t*)f->data, (size_t)f->size);
        w += (uint64_t)f->size;
        idx++;
    }

    *out_size = w;
    return 1;
}

static int run_elf64_from_fs_prefix(const char* prefix){
    uint64_t image_size = 0;

    if(!read_elf_chunks_from_fs(prefix, elf64_image_mem, (uint64_t)sizeof(elf64_image_mem), &image_size)){
        print64("FS read chunks failed\n", 0x4F);
        return 0;
    }

    elf64_info_t info;
    if(!elf64_validate(elf64_image_mem, image_size, &info)){
        print64("ELF64 validate failed\n", 0x4F);
        return 0;
    }

    if(info.high_vaddr <= info.low_vaddr){
        print64("ELF64 range invalid\n", 0x4F);
        return 0;
    }
    if(info.low_vaddr < 0x200000 || info.high_vaddr > 0x40000000){
        print64("ELF64 vaddr out of range\n", 0x4F);
        return 0;
    }

    uint64_t entry_off = 0;
    uint64_t load_span = info.high_vaddr - info.low_vaddr;
    if(!elf64_load_pt_load_segments(
            elf64_image_mem,
            image_size,
            (uint8_t*)(uintptr_t)info.low_vaddr,
            load_span,
            info.low_vaddr,
            &entry_off)){
        print64("ELF64 load failed\n", 0x4F);
        return 0;
    }

    uint64_t entry_addr = info.low_vaddr + entry_off;
    uint64_t user_rsp = (uint64_t)(user_stack + sizeof(user_stack) - 16);

    print64("ELF64 loaded from FS, entering ring3 entry...\n", 0x1A);
    enter_user_mode64(entry_addr, user_rsp);
    print64("ELF64 ring3 returned unexpectedly\n", 0x4F);
    return 1;
}

static int run_elf64_from_disk_manifest(const char* prefix){
    uint8_t manifest[512];
    if(ata_read_sector(USER64_MANIFEST_SECTOR, manifest) != 0) return 0;

    if(!(manifest[0]=='U' && manifest[1]=='6' && manifest[2]=='4' && manifest[3]=='M')) return 0;

    char mpfx[13];
    for(int i=0;i<12;i++) mpfx[i] = (char)manifest[4+i];
    mpfx[12] = 0;

    if(kstrcmp(mpfx, prefix) != 0) return 0;

    uint32_t chunk_count = rd_le32(&manifest[16]);
    uint32_t total_size  = rd_le32(&manifest[20]);
    uint32_t start_lba   = rd_le32(&manifest[24]);

    if(chunk_count == 0 || total_size == 0) return 0;
    if(total_size > sizeof(elf64_image_mem)) return 0;

    uint64_t w = 0;
    uint8_t sec[512];
    for(uint32_t i=0;i<chunk_count;i++){
        if(ata_read_sector(start_lba + i, sec) != 0) return 0;
        uint64_t left = (uint64_t)total_size - w;
        uint64_t n = left > 512 ? 512 : left;
        kmemcpy(elf64_image_mem + w, sec, (size_t)n);
        w += n;
        if(w >= total_size) break;
    }

    elf64_info_t info;
    if(!elf64_validate(elf64_image_mem, total_size, &info)) return 0;

        if(info.high_vaddr <= info.low_vaddr) return 0;
        if(info.low_vaddr < 0x200000 || info.high_vaddr > 0x40000000) return 0;

    uint64_t entry_off = 0;
        uint64_t load_span = info.high_vaddr - info.low_vaddr;
    if(!elf64_load_pt_load_segments(
            elf64_image_mem,
            total_size,
            (uint8_t*)(uintptr_t)info.low_vaddr,
            load_span,
            info.low_vaddr,
            &entry_off)) return 0;

        uint64_t entry_addr = info.low_vaddr + entry_off;
    uint64_t user_rsp = (uint64_t)(user_stack + sizeof(user_stack) - 16);

    print64("ELF64 loaded from disk manifest, entering ring3...\n", 0x1A);
    enter_user_mode64(entry_addr, user_rsp);
    print64("ELF64 ring3 returned unexpectedly\n", 0x4F);
    return 1;
}

static void run_user_boot_target(void){
    print64("User target prefix: ", 0x1F);
    print64(boot_user_prefix, 0x1E);
    print64("\n", 0x1F);

    if(run_elf64_from_disk_manifest(boot_user_prefix)) return;
    print64("No matching disk manifest, trying FS chunks...\n", 0x1E);

    if(!has_elf_chunks_in_fs(boot_user_prefix)){
        print64("No FS chunks for prefix, seeding demo...\n", 0x1E);
        if(!write_elf_chunks_to_fs(boot_user_prefix, user64_demo_elf, (uint64_t)user64_demo_elf_len)){
            print64("FS write chunks failed\n", 0x4F);
            return;
        }
    }

    if(!run_elf64_from_fs_prefix(boot_user_prefix)){
        print64("User launch failed\n", 0x4F);
    }
}

void kernel64_main(void){
    clear64(0x1F);
    print64("xyuOS 64-bit stage\n", 0x1F);
    print64("Long mode boot: OK\n", 0x1E);
    ata_init();
    fs_init();
    load_boot_prefix_from_fs();
    idt64_init();

    const char* msg = "IDT64 + int 0x80: OK\n";
    __asm__ volatile(
        "mov $1, %%rax\n"
        "mov %0, %%rbx\n"
        "int $0x80\n"
        :
        : "r"(msg)
        : "rax", "rbx", "memory"
    );

    __asm__ volatile(
        "mov $2, %%rax\n"
        "mov $64, %%rbx\n"
        "int $0x80\n"
        :
        :
        : "rax", "rbx", "memory"
    );
    print64("-bit syscall path\n", 0x1F);

    uint64_t rc = 0;
    __asm__ volatile(
        "mov $99, %%rax\n"
        "int $0x80\n"
        "mov %%rax, %0\n"
        : "=r"(rc)
        :
        : "rax", "memory"
    );
    print64("syscall return test: ", 0x1F);
    print_u64(rc, 0x1E);
    print64("\n", 0x1F);

    print64("Next: ELF64 loader + user mode\n", 0x1F);
    print64("ELF64 module linked\n", 0x1A);
    print64("Auto-run skipped: use shell command 'run'\n", 0x1E);
    shell_loop64();
}
