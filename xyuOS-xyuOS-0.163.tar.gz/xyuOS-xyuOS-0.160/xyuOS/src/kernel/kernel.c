extern void isr32();
extern void isr33();
extern void isr128();




#include "../drivers/vga.h"
#include "../drivers/pic.h"
#include "../drivers/pit.h"
#include "../drivers/keyboard.h"
#include "../drivers/ata.h"
#include "../cpu/gdt.h"
#include "../cpu/idt.h"
#include "../util/string.h"
#include "../fs/fs.h"
#include <stdint.h>
#include "../editor/editor.h"




#define ED_X 2
#define ED_Y 4
#define ED_W 34
#define ED_H 12

#define CON_X 42
#define CON_Y 4
#define CON_W 34
#define CON_H 10

#define IN_X  42
#define IN_Y  16

static int conx = 0, cony = 0;
static char input[128];
static int inlen = 0;


static file_t* cur_file = 0;

static void disk_load(file_t* f);
static void disk_save(file_t* f);



static void con_clear(void){
    for(int y=0;y<CON_H;y++)
        for(int x=0;x<CON_W;x++)
            vga_print(CON_X+x, CON_Y+y, " ", 0x07);
    conx = cony = 0;
}

static void con_putc(char c){
    if(c=='\n'){
        conx = 0;
        if(++cony >= CON_H) cony = CON_H - 1;
        return;
    }
    char s[2] = {c,0};
    vga_print(CON_X+conx, CON_Y+cony, s, 0x07);
    if(++conx >= CON_W){
        conx = 0;
        if(++cony >= CON_H) cony = CON_H - 1;
    }
}

static void con_print(const char* s){
    for(size_t i=0;i<kstrlen(s);i++)
        con_putc(s[i]);
}

static int str_ends_with(const char* s, const char* suffix){
    int sl = (int)kstrlen(s);
    int xl = (int)kstrlen(suffix);
    if(xl > sl) return 0;
    return kstrcmp(s + sl - xl, suffix) == 0;
}

static const char* skip_spaces(const char* s){
    while(*s==' ' || *s=='\t') s++;
    return s;
}

typedef struct {
    uint32_t edi, esi, ebp, esp, ebx, edx, ecx, eax;
} int80_regs_t;

enum {
    SYS_PUTS = 1,
    SYS_PUTI = 2,
    SYS_CLS  = 3
};

static uint8_t user_exec_buf[MAX_FILE_SIZE];

static const char demo_asm_hex[] =
    "# demo-asm\n"
    "b8 01 00 00 00 bb 25 00 00 00 cd 80 b8 02 00 00\n"
    "00 bb 39 30 00 00 cd 80 b8 01 00 00 00 bb 3a 00\n"
    "00 00 cd 80 c3 68 65 6c 6c 6f 20 66 72 6f 6d 20\n"
    "72 65 61 6c 20 61 73 6d 0a 00 0a 00\n";

static const char demo_c_hex[] =
    "# demo-c\n"
    "ba 01 00 00 00 53 bb 26 00 00 00 89 d0 cd 80 b8\n"
    "02 00 00 00 bb ea 07 00 00 cd 80 bb 37 00 00 00\n"
    "89 d0 cd 80 5b c3 68 65 6c 6c 6f 20 66 72 6f 6d\n"
    "20 72 65 61 6c 20 63 0a 00\n";

static int is_hex(char c){
    return (c>='0'&&c<='9') || (c>='a'&&c<='f') || (c>='A'&&c<='F');
}

static void con_print_int(int value){
    char buf[16];
    int i = 0;
    if(value == 0){
        con_putc('0');
        return;
    }
    if(value < 0){
        con_putc('-');
        value = -value;
    }
    while(value && i < (int)sizeof(buf)){
        buf[i++] = (char)('0' + (value % 10));
        value /= 10;
    }
    while(i--) con_putc(buf[i]);
}

static void set_new_file_template(file_t* f){
    if(!f) return;

    const char* tpl = 0;
    if(str_ends_with(f->name, ".c")){
        tpl =
            "// native c subset for: cc file.c out.bin\n"
            "sys_puts(\"hello from c\\n\");\n"
            "sys_puti(123);\n"
            "sys_cls();\n"
            "sys_puts(\"done\\n\");\n";
    } else if(str_ends_with(f->name, ".asm")){
        tpl =
            "; native asm for: asm file.asm out.bin\n"
            "start:\n"
            "mov eax, 1\n"
            "mov ebx, msg\n"
            "int 0x80\n"
            "ret\n"
            "msg: db 'hello from asm',10,0\n";
    } else if(str_ends_with(f->name, ".bin")){
        tpl =
            "# paste hex bytes of flat 32-bit binary here\n"
            "# example: B8 01 00 00 00 BB ...\n"
            "# or use: loadbin demo-c myprog.bin\n";
    }

    if(!tpl) return;

    int n = (int)kstrlen(tpl);
    if(n >= MAX_FILE_SIZE) n = MAX_FILE_SIZE - 1;
    kmemcpy(f->data, tpl, n);
    f->data[n] = 0;
    f->size = n;
}

static void fill_name(char* dst, int dst_max, const char* src){
    int i = 0;
    while(src[i] && i < dst_max-1){
        dst[i] = src[i];
        i++;
    }
    dst[i] = 0;
}

static void load_builtin_bin(const char* which, const char* target){
    const char* payload = 0;
    if(kstrcmp(which, "demo-c") == 0) payload = demo_c_hex;
    else if(kstrcmp(which, "demo-asm") == 0) payload = demo_asm_hex;

    if(!payload){
        con_print("usage: loadbin demo-c|demo-asm [name.bin]\n");
        return;
    }

    file_t* f = fs_get(target);
    if(!f){
        f = fs_create(target);
        if(!f){
            con_print("loadbin failed: fs full\n");
            return;
        }
    }

    int n = (int)kstrlen(payload);
    if(n >= MAX_FILE_SIZE) n = MAX_FILE_SIZE - 1;
    kmemcpy(f->data, payload, n);
    f->data[n] = 0;
    f->size = n;
    disk_save(f);

    con_print("loaded bin: ");
    con_print(f->name);
    con_putc('\n');
}

static int decode_hex_file_to_bin(file_t* f, uint8_t* out, int out_max){
    disk_load(f);

    int n = 0;
    int i = 0;
    while(i < f->size){
        char c = f->data[i];

        if(c==' ' || c=='\t' || c=='\r' || c=='\n' || c==','){
            i++;
            continue;
        }
        if(c=='#' || c==';'){
            while(i < f->size && f->data[i] != '\n') i++;
            continue;
        }
        if(c=='/' && i+1 < f->size && f->data[i+1]=='/'){
            while(i < f->size && f->data[i] != '\n') i++;
            continue;
        }

        if(i+1 >= f->size || !is_hex(f->data[i]) || !is_hex(f->data[i+1])){
            return -1;
        }
        if(n >= out_max) return -2;

        char hex[3];
        hex[0] = f->data[i];
        hex[1] = f->data[i+1];
        hex[2] = 0;

        if(!kparse_hex_byte(hex, &out[n])) return -1;
        n++;
        i += 2;
    }

    return n;
}

static void run_binary_buffer(const uint8_t* code, int size){
    if(size <= 0){
        con_print("[run] empty program\n");
        return;
    }
    if(size > MAX_FILE_SIZE){
        con_print("[run] program too large\n");
        return;
    }

    kmemcpy(user_exec_buf, code, (size_t)size);
    void (*entry)(void) = (void(*)(void))user_exec_buf;
    entry();
}

static void run_binary_file(file_t* f){
    if(!f) return;
    if(!str_ends_with(f->name, ".bin")){
        con_print("[run] real run supports only .bin\n");
        return;
    }

    int n = decode_hex_file_to_bin(f, user_exec_buf, MAX_FILE_SIZE);
    if(n == -1){
        con_print("[run] invalid hex format\n");
        return;
    }
    if(n == -2){
        con_print("[run] binary too large\n");
        return;
    }
    if(n == 0){
        con_print("[run] no hex bytes found\n");
        return;
    }

    run_binary_buffer(user_exec_buf, n);
}

typedef struct {
    char name[32];
    int addr;
} asm_label_t;

static int ch_is_digit(char c){ return c>='0' && c<='9'; }
static int ch_is_alpha(char c){ return (c>='a'&&c<='z') || (c>='A'&&c<='Z'); }
static int ch_is_ident_start(char c){ return ch_is_alpha(c) || c=='_'; }
static int ch_is_ident_char(char c){ return ch_is_ident_start(c) || ch_is_digit(c); }

static int streq(const char* a, const char* b){ return kstrcmp(a,b)==0; }

static void trim_ws(char* s){
    int start = 0;
    while(s[start]==' ' || s[start]=='\t' || s[start]=='\r') start++;
    if(start){
        int j = 0;
        while(s[start]) s[j++] = s[start++];
        s[j] = 0;
    }
    int n = (int)kstrlen(s);
    while(n>0 && (s[n-1]==' ' || s[n-1]=='\t' || s[n-1]=='\r')) s[--n] = 0;
}

static void strip_comment(char* s){
    for(int i=0;s[i];i++){
        if(s[i]==';' || s[i]=='#'){ s[i]=0; break; }
        if(s[i]=='/' && s[i+1]=='/'){ s[i]=0; break; }
    }
}

static int parse_dec_int(const char** pp, int* out){
    const char* p = skip_spaces(*pp);
    int sign = 1;
    if(*p=='-'){ sign=-1; p++; }
    else if(*p=='+'){ p++; }
    if(!ch_is_digit(*p)) return 0;
    int v = 0;
    while(ch_is_digit(*p)){
        v = v*10 + (*p - '0');
        p++;
    }
    *out = v * sign;
    *pp = p;
    return 1;
}

static int parse_hex_int(const char** pp, int* out){
    const char* p = skip_spaces(*pp);
    if(!(p[0]=='0' && (p[1]=='x' || p[1]=='X'))) return 0;
    p += 2;
    int any = 0;
    int v = 0;
    while(is_hex(*p)){
        int d = 0;
        if(*p>='0'&&*p<='9') d = *p-'0';
        else if(*p>='a'&&*p<='f') d = 10 + (*p-'a');
        else d = 10 + (*p-'A');
        v = (v<<4) | d;
        p++;
        any = 1;
    }
    if(!any) return 0;
    *out = v;
    *pp = p;
    return 1;
}

static int parse_number(const char** pp, int* out){
    const char* p = *pp;
    if(parse_hex_int(&p, out)){ *pp = p; return 1; }
    if(parse_dec_int(&p, out)){ *pp = p; return 1; }
    return 0;
}

static int parse_ident(const char** pp, char* out, int out_max){
    const char* p = skip_spaces(*pp);
    if(!ch_is_ident_start(*p)) return 0;
    int n = 0;
    while(ch_is_ident_char(*p)){
        if(n < out_max-1) out[n++] = *p;
        p++;
    }
    out[n] = 0;
    *pp = p;
    return 1;
}

static int expect_char(const char** pp, char c){
    const char* p = skip_spaces(*pp);
    if(*p != c) return 0;
    p++;
    *pp = p;
    return 1;
}

static int find_label(asm_label_t* labels, int count, const char* name){
    for(int i=0;i<count;i++) if(streq(labels[i].name, name)) return i;
    return -1;
}

static int parse_db_items_size(const char* p){
    int size = 0;
    for(;;){
        p = skip_spaces(p);
        if(*p==0) break;
        if(*p=='\''){ // string literal in single quotes
            p++;
            while(*p && *p!='\''){
                if(*p=='\\' && p[1]) p++;
                size++;
                p++;
            }
            if(*p!='\'') return -1;
            p++;
        } else {
            int v = 0;
            if(!parse_number(&p, &v)) return -1;
            size++;
        }
        p = skip_spaces(p);
        if(*p==','){ p++; continue; }
        if(*p==0) break;
        return -1;
    }
    return size;
}

static int emit_db_items(uint8_t* out, int* pc, int max, const char* p){
    for(;;){
        p = skip_spaces(p);
        if(*p==0) break;
        if(*p=='\''){
            p++;
            while(*p && *p!='\''){
                char c = *p;
                if(c=='\\' && p[1]){
                    p++;
                    c = *p;
                    if(c=='n') c = '\n';
                    else if(c=='t') c = '\t';
                }
                if(*pc >= max) return 0;
                out[(*pc)++] = (uint8_t)c;
                p++;
            }
            if(*p!='\'') return 0;
            p++;
        } else {
            int v = 0;
            if(!parse_number(&p, &v)) return 0;
            if(*pc >= max) return 0;
            out[(*pc)++] = (uint8_t)(v & 0xFF);
        }
        p = skip_spaces(p);
        if(*p==','){ p++; continue; }
        if(*p==0) break;
        return 0;
    }
    return 1;
}

static int asm_insn_size(const char* line){
    const char* p = line;
    char op[16];
    if(!parse_ident(&p, op, (int)sizeof(op))) return -1;

    if(streq(op, "ret")) return 1;
    if(streq(op, "int")) return 2;
    if(streq(op, "mov")){
        char reg[16];
        if(!parse_ident(&p, reg, (int)sizeof(reg))) return -1;
        if(!expect_char(&p, ',')) return -1;
        if(streq(reg, "eax") || streq(reg, "ebx")) return 5;
        return -1;
    }
    if(streq(op, "db")){
        int sz = parse_db_items_size(p);
        return sz;
    }
    return -1;
}

static int asm_emit_insn(uint8_t* out, int* pc, int max, const char* line, asm_label_t* labels, int label_count){
    const char* p = line;
    char op[16];
    if(!parse_ident(&p, op, (int)sizeof(op))) return 0;

    if(streq(op, "ret")){
        if(*pc >= max) return 0;
        out[(*pc)++] = 0xC3;
        return 1;
    }

    if(streq(op, "int")){
        int v = 0;
        if(!parse_number(&p, &v)) return 0;
        if(v != 0x80 && v != 128) return 0;
        if(*pc + 2 > max) return 0;
        out[(*pc)++] = 0xCD;
        out[(*pc)++] = 0x80;
        return 1;
    }

    if(streq(op, "mov")){
        char reg[16];
        if(!parse_ident(&p, reg, (int)sizeof(reg))) return 0;
        if(!expect_char(&p, ',')) return 0;

        int imm = 0;
        if(!parse_number(&p, &imm)){
            char lbl[32];
            if(!parse_ident(&p, lbl, (int)sizeof(lbl))) return 0;
            int li = find_label(labels, label_count, lbl);
            if(li < 0) return 0;
            imm = labels[li].addr;
        }

        p = skip_spaces(p);
        if(*p != 0) return 0;

        if(*pc + 5 > max) return 0;
        if(streq(reg, "eax")) out[(*pc)++] = 0xB8;
        else if(streq(reg, "ebx")) out[(*pc)++] = 0xBB;
        else return 0;

        out[(*pc)++] = (uint8_t)(imm & 0xFF);
        out[(*pc)++] = (uint8_t)((imm >> 8) & 0xFF);
        out[(*pc)++] = (uint8_t)((imm >> 16) & 0xFF);
        out[(*pc)++] = (uint8_t)((imm >> 24) & 0xFF);
        return 1;
    }

    if(streq(op, "db")) return emit_db_items(out, pc, max, p);

    return 0;
}

static int assemble_source_to_bin(const char* src, int src_len, uint8_t* out, int out_max, int* out_size){
    asm_label_t labels[64];
    int label_count = 0;
    char line[160];
    int pc = 0;

    int i = 0;
    while(i <= src_len){
        int ll = 0;
        while(i < src_len && src[i] != '\n' && ll < (int)sizeof(line)-1) line[ll++] = src[i++];
        if(i < src_len && src[i]=='\n') i++;
        line[ll] = 0;

        strip_comment(line);
        trim_ws(line);
        if(line[0]==0) continue;

        const char* p = line;
        char lbl[32];
        if(parse_ident(&p, lbl, (int)sizeof(lbl))){
            const char* q = skip_spaces(p);
            if(*q==':'){
                if(label_count >= 64) return 0;
                if(find_label(labels, label_count, lbl) >= 0) return 0;
                fill_name(labels[label_count].name, (int)sizeof(labels[label_count].name), lbl);
                labels[label_count].addr = pc;
                label_count++;
                q++;
                while(*q==' '||*q=='\t') q++;
                if(*q==0) continue;
                int sz = asm_insn_size(q);
                if(sz < 0) return 0;
                pc += sz;
                if(pc > out_max) return 0;
                continue;
            }
        }

        int sz = asm_insn_size(line);
        if(sz < 0) return 0;
        pc += sz;
        if(pc > out_max) return 0;
    }

    i = 0;
    pc = 0;
    while(i <= src_len){
        int ll = 0;
        while(i < src_len && src[i] != '\n' && ll < (int)sizeof(line)-1) line[ll++] = src[i++];
        if(i < src_len && src[i]=='\n') i++;
        line[ll] = 0;

        strip_comment(line);
        trim_ws(line);
        if(line[0]==0) continue;

        const char* p = line;
        char lbl[32];
        if(parse_ident(&p, lbl, (int)sizeof(lbl))){
            const char* q = skip_spaces(p);
            if(*q==':'){
                q++;
                while(*q==' '||*q=='\t') q++;
                if(*q==0) continue;
                if(!asm_emit_insn(out, &pc, out_max, q, labels, label_count)) return 0;
                continue;
            }
        }

        if(!asm_emit_insn(out, &pc, out_max, line, labels, label_count)) return 0;
    }

    *out_size = pc;
    return 1;
}

typedef struct {
    int kind; // 1 puts, 2 puti, 3 cls
    int value;
    char text[96];
} c_op_t;

static int parse_c_line(char* line, c_op_t* out){
    strip_comment(line);
    trim_ws(line);
    if(line[0]==0) return 0;

    if(kstartswith(line, "sys_cls(")){
        out->kind = 3;
        return 1;
    }

    if(kstartswith(line, "sys_puti(")){
        const char* p = line + 9;
        int v = 0;
        if(!parse_number(&p, &v)) return -1;
        out->kind = 2;
        out->value = v;
        return 1;
    }

    if(kstartswith(line, "sys_puts(")){
        const char* p = line + 9;
        p = skip_spaces(p);
        if(*p != '"') return -1;
        p++;
        int n = 0;
        while(*p && *p!='"'){
            char c = *p;
            if(c=='\\' && p[1]){
                p++;
                c = *p;
                if(c=='n') c='\n';
                else if(c=='t') c='\t';
            }
            if(n < (int)sizeof(out->text)-1) out->text[n++] = c;
            p++;
        }
        if(*p != '"') return -1;
        out->text[n] = 0;
        out->kind = 1;
        return 1;
    }

    if(streq(line, "ret;") || streq(line, "return;") || streq(line, "}")){
        out->kind = 0;
        return 1;
    }

    return -1;
}

static int compile_c_source_to_bin(const char* src, int src_len, uint8_t* out, int out_max, int* out_size){
    c_op_t ops[64];
    int op_count = 0;
    char line[160];

    int i = 0;
    while(i <= src_len){
        int ll = 0;
        while(i < src_len && src[i] != '\n' && ll < (int)sizeof(line)-1) line[ll++] = src[i++];
        if(i < src_len && src[i]=='\n') i++;
        line[ll] = 0;

        c_op_t op;
        int r = parse_c_line(line, &op);
        if(r == 0) continue;
        if(r < 0) return 0;
        if(op.kind == 0) continue;
        if(op_count >= 64) return 0;
        ops[op_count++] = op;
    }

    int code_size = 0;
    int data_size = 0;
    for(int k=0;k<op_count;k++){
        if(ops[k].kind==1) { code_size += 12; data_size += (int)kstrlen(ops[k].text) + 1; }
        else if(ops[k].kind==2) code_size += 12;
        else if(ops[k].kind==3) code_size += 7;
    }
    code_size += 1; // ret

    if(code_size + data_size > out_max) return 0;

    int pc = 0;
    int data_ptr = code_size;
    for(int k=0;k<op_count;k++){
        if(ops[k].kind==1){
            int addr = data_ptr;
            int sl = (int)kstrlen(ops[k].text) + 1;
            kmemcpy(out + data_ptr, ops[k].text, (size_t)sl);
            data_ptr += sl;

            out[pc++] = 0xB8; out[pc++] = 1; out[pc++] = 0; out[pc++] = 0; out[pc++] = 0;
            out[pc++] = 0xBB;
            out[pc++] = (uint8_t)(addr & 0xFF);
            out[pc++] = (uint8_t)((addr>>8) & 0xFF);
            out[pc++] = (uint8_t)((addr>>16) & 0xFF);
            out[pc++] = (uint8_t)((addr>>24) & 0xFF);
            out[pc++] = 0xCD; out[pc++] = 0x80;
        } else if(ops[k].kind==2){
            int v = ops[k].value;
            out[pc++] = 0xB8; out[pc++] = 2; out[pc++] = 0; out[pc++] = 0; out[pc++] = 0;
            out[pc++] = 0xBB;
            out[pc++] = (uint8_t)(v & 0xFF);
            out[pc++] = (uint8_t)((v>>8) & 0xFF);
            out[pc++] = (uint8_t)((v>>16) & 0xFF);
            out[pc++] = (uint8_t)((v>>24) & 0xFF);
            out[pc++] = 0xCD; out[pc++] = 0x80;
        } else if(ops[k].kind==3){
            out[pc++] = 0xB8; out[pc++] = 3; out[pc++] = 0; out[pc++] = 0; out[pc++] = 0;
            out[pc++] = 0xCD; out[pc++] = 0x80;
        }
    }
    out[pc++] = 0xC3;

    *out_size = data_ptr;
    return 1;
}

static int write_bin_as_hex_file(file_t* out_file, const uint8_t* bin, int bin_size){
    if(!out_file || !bin || bin_size<=0) return 0;

    static const char* hx = "0123456789abcdef";
    int w = 0;
    const char* hdr = "# generated in xyuOS\n";
    for(int i=0;hdr[i];i++){
        if(w >= MAX_FILE_SIZE-1) return 0;
        out_file->data[w++] = hdr[i];
    }

    for(int i=0;i<bin_size;i++){
        if(w + 3 >= MAX_FILE_SIZE-1) return 0;
        uint8_t b = bin[i];
        out_file->data[w++] = hx[(b>>4)&0xF];
        out_file->data[w++] = hx[b&0xF];
        out_file->data[w++] = ' ';
        if((i % 16) == 15){
            if(w >= MAX_FILE_SIZE-1) return 0;
            out_file->data[w++] = '\n';
        }
    }
    if(w>0 && out_file->data[w-1] != '\n') out_file->data[w++] = '\n';
    out_file->data[w] = 0;
    out_file->size = w;
    return 1;
}

static void compile_in_os(const char* mode, const char* src_name, const char* out_name){
    file_t* src = fs_get(src_name);
    if(!src){ con_print("compile: source not found\n"); return; }
    disk_load(src);

    file_t* out = fs_get(out_name);
    if(!out){
        out = fs_create(out_name);
        if(!out){ con_print("compile: cannot create output\n"); return; }
    }

    uint8_t bin[MAX_FILE_SIZE];
    int bin_size = 0;
    int ok = 0;

    if(streq(mode, "asm")) ok = assemble_source_to_bin(src->data, src->size, bin, MAX_FILE_SIZE, &bin_size);
    else if(streq(mode, "cc")) ok = compile_c_source_to_bin(src->data, src->size, bin, MAX_FILE_SIZE, &bin_size);

    if(!ok){
        con_print("compile: syntax/error\n");
        return;
    }

    if(!write_bin_as_hex_file(out, bin, bin_size)){
        con_print("compile: output too big\n");
        return;
    }

    disk_save(out);
    con_print("compiled -> ");
    con_print(out->name);
    con_putc('\n');
}



// interactive editor implemented in src/editor



static void draw_ui(void){
    vga_clear(0x00);
    vga_box(0,0,80,25,0x07);

    vga_box(1,1,38,17,0x0F);
    vga_print(3,2,"TEXT EDITOR",0x0C);

    vga_box(40,1,38,14,0x07);
    vga_print(42,2,"CONSOLE",0x0C);

    vga_box(40,15,38,3,0x07);
    vga_print(42,16,">",0x0F);

    vga_box(1,19,78,5,0x07);
    vga_print(3,20,"error",0x0C);

    con_clear();
    con_print("WELCOME TO XUYOS 0.160 |write help if you need help|\n");
}

static void redraw_input(void){
    for(int i=0;i<34;i++)
        vga_print(IN_X+i, IN_Y, " ", 0x07);
    input[inlen] = 0;
    vga_print(IN_X, IN_Y, input, 0x0F);
}



static void disk_save(file_t* f){
    if(!f) return;
    __asm__ volatile("cli");
    ata_write_sector(f->sector, (uint8_t*)f->data);
    __asm__ volatile("sti");
}

static void disk_load(file_t* f){
    if(!f) return;
    __asm__ volatile("cli");
    ata_read_sector(f->sector, (uint8_t*)f->data);
    __asm__ volatile("sti");
    f->data[MAX_FILE_SIZE - 1] = 0;
    f->size = kstrlen(f->data);
}

static void cmd_cpu(void){
    uint32_t eax, ebx, ecx, edx;
    char vendor[13];

    __asm__ volatile(
        "cpuid"
        : "=b"(ebx), "=d"(edx), "=c"(ecx)
        : "a"(0)
    );

    *(uint32_t*)&vendor[0] = ebx;
    *(uint32_t*)&vendor[4] = edx;
    *(uint32_t*)&vendor[8] = ecx;
    vendor[12] = 0;

    con_print("CPU: ");
    con_print(vendor);
    con_putc('\n');
}





static void exec_command(const char* cmd){





    if(kstrcmp(cmd,"uptime")==0){
        uint32_t t = pit_ticks();
        con_print("ticks: ");

        char buf[16];
        int i = 0;
        if(t == 0){
            buf[i++] = '0';
        } else {
            char tmp[16];
            int j = 0;
            while(t){
                tmp[j++] = '0' + (t % 10);
                t /= 10;
            }
            while(j--) buf[i++] = tmp[j];
        }
        buf[i] = 0;

        con_print(buf);
        con_putc('\n');
        return;
    }


    if(kstrcmp(cmd,"cpu")==0){
        cmd_cpu();
        return;
    }

    if(kstartswith(cmd,"rm ")){
        file_t* f = fs_get(cmd+3);
        if(!f){
            con_print("file not found\n");
            return;
        }
        f->used = 0;
        con_print("removed\n");
        return;
    }



    if(kstartswith(cmd,"cat ")){
        file_t* f = fs_get(cmd+4);
        if(!f){
            con_print("file not found\n");
            return;
        }
        con_print(f->data);
        con_putc('\n');
        return;
    }


    if(kstrcmp(cmd,"clear")==0){
        con_clear();
        return;
    }


    if(kstrcmp(cmd,"help")==0){
        con_print("|- ls, new, open, loadbin, run(.bin), write, save, clear, cat, rm, cpu, uptime, sys. -|\n");
        con_print("|- real gcc/nasm: use 64-bit flow from host: make run64-asm ASM_SRC=user64/<name>.asm -|\n");
        return;
    }

    if(kstrcmp(cmd,"ls")==0){
        int n = fs_count();
        for(int i=0;i<n;i++){
            file_t* f = fs_at(i);
            con_print(" - ");
            con_print(f->name);
            con_putc('\n');
        }
        return;
    }

    if(kstartswith(cmd,"new ")){
        const char* p = cmd + 4;
        int created = 0;
        file_t* first_created = 0;

        while(*p){
            p = skip_spaces(p);
            if(!*p) break;

            char name[MAX_FILENAME];
            int n = 0;
            while(*p && *p!=' ' && *p!='\t'){
                if(n < MAX_FILENAME-1) name[n++] = *p;
                p++;
            }
            name[n] = 0;

            if(name[0] == 0) continue;

            if(fs_get(name)){
                con_print("file exists: ");
                con_print(name);
                con_putc('\n');
                continue;
            }

            file_t* f = fs_create(name);
            if(!f){
                con_print("file create failed: ");
                con_print(name);
                con_putc('\n');
                continue;
            }

            set_new_file_template(f);

            if(!first_created) first_created = f;
            created++;
            con_print("created: ");
            con_print(name);
            con_putc('\n');
        }

        if(created == 1 && first_created){
            cur_file = first_created;
            editor_set_area(ED_X, ED_Y, ED_W, ED_H);
            editor_open(cur_file);
            editor_draw();
        } else if(created == 0){
            con_print("usage: new <file1> [file2 ...]\n");
        }
        return;
    }

    if(kstartswith(cmd,"open ")){
        cur_file = fs_get(cmd+5);
        if(cur_file){ disk_load(cur_file); editor_set_area(ED_X, ED_Y, ED_W, ED_H); editor_open(cur_file); editor_draw(); }
        else { con_print("file not found\n"); }
        return;
    }

    if(kstartswith(cmd,"run ")){
        const char* name = skip_spaces(cmd+4);
        if(!*name){
            con_print("usage: run <file>\n");
            return;
        }

        file_t* f = fs_get(name);
        if(!f){
            con_print("file not found\n");
            return;
        }

        run_binary_file(f);
        return;
    }

    if(kstartswith(cmd,"asm ")){
        con_print("asm in 32-bit shell is disabled (fake assembler).\n");
        con_print("use real nasm/gcc pipeline:\n");
        con_print("  make all64 && make inject64-asm ASM_SRC=user64/<name>.asm\n");
        con_print("  make run64\n");
        return;
    }

    if(kstartswith(cmd,"cc ")){
        con_print("cc in 32-bit shell is disabled (fake compiler).\n");
        con_print("use real gcc/nasm pipeline:\n");
        con_print("  make all64 && make inject64-user USER64_SRC=user64/<name>.c\n");
        con_print("  make run64\n");
        return;
    }

    if(kstartswith(cmd,"loadbin ")){
        const char* p = skip_spaces(cmd+8);
        if(!*p){
            con_print("usage: loadbin demo-c|demo-asm [name.bin]\n");
            return;
        }

        char kind[16];
        int k = 0;
        while(*p && *p!=' ' && *p!='\t'){
            if(k < (int)sizeof(kind)-1) kind[k++] = *p;
            p++;
        }
        kind[k] = 0;

        p = skip_spaces(p);

        char target[MAX_FILENAME];
        if(*p){
            int t = 0;
            while(*p && *p!=' ' && *p!='\t'){
                if(t < MAX_FILENAME-1) target[t++] = *p;
                p++;
            }
            target[t] = 0;
        } else {
            if(kstrcmp(kind, "demo-c") == 0) fill_name(target, MAX_FILENAME, "demo_c.bin");
            else if(kstrcmp(kind, "demo-asm") == 0) fill_name(target, MAX_FILENAME, "demo_asm.bin");
            else target[0] = 0;
        }

        if(target[0] == 0){
            con_print("usage: loadbin demo-c|demo-asm [name.bin]\n");
            return;
        }

        load_builtin_bin(kind, target);
        return;
    }

    if(kstartswith(cmd,"write ")){
        con_print("'write' is deprecated — use interactive editor (new/open)\n");
        return;
    }

    if(kstrcmp(cmd,"save")==0){
        if(cur_file) disk_save(cur_file);
        return;
    }



    if(kstrcmp(cmd,"sys")==0){
      con_print("xyuOS\n");
      con_print("Mode: kernel\n");
      con_print("FS: simple sector fs\n");
      con_print("IRQ: enabled\n");
      return;
    }

    con_print("?\n");
}

uint32_t isr80_handler(int80_regs_t* r){
    if(!r) return (uint32_t)-1;

    switch(r->eax){
        case SYS_PUTS:
            if(r->ebx) con_print((const char*)r->ebx);
            return 0;
        case SYS_PUTI:
            con_print_int((int)r->ebx);
            return 0;
        case SYS_CLS:
            con_clear();
            return 0;
        default:
            return (uint32_t)-1;
    }
}

void kernel_main(void){

    fs_init();
    draw_ui();

    gdt_init();
    idt_init();

    idt_set_gate(32, (uint32_t)isr32, 0x08, 0x8E);
    idt_set_gate(33, (uint32_t)isr33, 0x08, 0x8E);
    idt_set_gate(128, (uint32_t)isr128, 0x08, 0xEE);

    pic_remap(0x20,0x28);
    pic_set_mask(14);
    pic_clear_mask(0);
    pic_clear_mask(1);

    pit_init(100);
    keyboard_init();
    ata_init();

    __asm__ volatile("sti");

    // enable global blue theme (BSOD-like)
    vga_set_blue_theme(1);

    // redraw UI now that theme is enabled so background becomes blue everywhere
    draw_ui();
    editor_draw();

    for(;;){
        keycode_t k;
        while(keyboard_pop(&k)){
            if(editor_is_active()){
                // when editor active, route keys there
                editor_handle_key(k);
                editor_draw();
                continue;
            }

            if(k==KEY_F1 && cur_file){
                disk_load(cur_file);
                editor_draw();
            }

            else if(k==KEY_F2 && cur_file){
                disk_save(cur_file);
            }

            else if(k==KEY_ENTER){
                exec_command(input);
                inlen = 0;
                redraw_input();
            }

            else if(k==KEY_BKSP && inlen){
                input[--inlen] = 0;
                redraw_input();
            }

            else if(k>=32 && k<=126 && inlen < 127){
                input[inlen++] = (char)k;
                redraw_input();
            }
        }
        __asm__ volatile("hlt");
    }
}

