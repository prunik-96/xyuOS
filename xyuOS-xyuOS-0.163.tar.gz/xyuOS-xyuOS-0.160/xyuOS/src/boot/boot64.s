BITS 32
GLOBAL _start
EXTERN kernel64_main

SECTION .multiboot
align 8
mb2_header_start:
    dd 0xE85250D6                 ; multiboot2 magic
    dd 0                          ; architecture (i386)
    dd mb2_header_end - mb2_header_start
    dd -(0xE85250D6 + 0 + (mb2_header_end - mb2_header_start))

    align 8
    dw 0                          ; end tag type
    dw 0                          ; end tag flags
    dd 8                          ; end tag size
mb2_header_end:

SECTION .text
_start:
    cli

    ; Load page table root
    mov eax, pml4_table
    mov cr3, eax

    ; Enable PAE
    mov eax, cr4
    or eax, (1 << 5)
    mov cr4, eax

    ; Enable long mode (LME)
    mov ecx, 0xC0000080           ; EFER MSR
    rdmsr
    or eax, (1 << 8)
    wrmsr

    ; Enable paging
    mov eax, cr0
    or eax, (1 << 31)
    mov cr0, eax

    lgdt [gdt64_desc]
    jmp 0x08:long_mode_start

BITS 64
long_mode_start:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax

    mov rsp, stack_top

    lea rax, [rel stack_top]
    mov [tss64 + 4], rax

    lea rax, [rel tss64]
    mov rcx, rax

    mov word [gdt64_tss + 0], tss64_end - tss64 - 1
    mov word [gdt64_tss + 2], cx
    shr rcx, 16
    mov byte [gdt64_tss + 4], cl
    mov byte [gdt64_tss + 5], 0x89
    mov byte [gdt64_tss + 6], 0x00
    mov byte [gdt64_tss + 7], ch

    shr rax, 32
    mov dword [gdt64_tss + 8], eax
    mov dword [gdt64_tss + 12], 0

    mov ax, 0x28
    ltr ax

    call kernel64_main

.halt:
    hlt
    jmp .halt

SECTION .rodata
align 8
gdt64:
    dq 0x0000000000000000
    dq 0x00AF9A000000FFFF          ; 64-bit code segment
    dq 0x00AF92000000FFFF          ; data segment
    dq 0x00AFF2000000FFFF          ; user data segment (DPL=3)
    dq 0x00AFFA000000FFFF          ; user code segment (DPL=3)
gdt64_tss:
    dq 0x0000000000000000          ; TSS descriptor low (filled at runtime)
    dq 0x0000000000000000          ; TSS descriptor high
gdt64_end:

gdt64_desc:
    dw gdt64_end - gdt64 - 1
    dq gdt64

SECTION .data
align 4096
pml4_table:
    dq pdpt_table + 0x07
    times 511 dq 0

align 4096
pdpt_table:
    dq pd_table + 0x07
    times 511 dq 0

align 4096
pd_table:
%assign i 0
%rep 512
    dq (i * 0x200000) + 0x87      ; present|rw|user|2MiB page
%assign i i+1
%endrep

SECTION .bss
alignb 16
tss64:
    resb 104
tss64_end:

alignb 16
stack_bottom: resb 16384
stack_top:
