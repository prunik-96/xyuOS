BITS 64

GLOBAL enter_user_mode64
GLOBAL user_mode_entry

SECTION .text
user_mode_entry:
    mov rax, 1
    mov rbx, user_msg
    int 0x80

.hang:
    jmp .hang

; rdi = user RIP, rsi = user RSP
enter_user_mode64:
    push qword 0x1B          ; SS (user data selector | RPL3)
    push rsi                 ; RSP

    pushfq
    pop rax
    and rax, ~0x200          ; IF=0 (IRQ disabled until real IRQ handlers are added)
    push rax

    push qword 0x23          ; CS (user code selector | RPL3)
    push rdi                 ; RIP
    iretq

SECTION .rodata
user_msg db 'Hello from ring3 via int80', 10, 0
