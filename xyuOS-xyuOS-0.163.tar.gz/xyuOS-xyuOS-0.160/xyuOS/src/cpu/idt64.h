#pragma once
#include <stdint.h>

typedef struct regs64 {
  uint64_t rax, rbx, rcx, rdx, rsi, rdi, rbp;
  uint64_t r8, r9, r10, r11, r12, r13, r14, r15;
} regs64_t;

void idt64_init(void);
uint64_t isr80_handler64(regs64_t* r);
