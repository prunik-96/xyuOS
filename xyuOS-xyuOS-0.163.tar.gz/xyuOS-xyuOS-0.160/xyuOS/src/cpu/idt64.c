#include "idt64.h"

typedef struct {
  uint16_t offset_low;
  uint16_t selector;
  uint8_t  ist;
  uint8_t  type_attr;
  uint16_t offset_mid;
  uint32_t offset_high;
  uint32_t zero;
} __attribute__((packed)) idt64_entry_t;

typedef struct {
  uint16_t limit;
  uint64_t base;
} __attribute__((packed)) idt64_ptr_t;

static idt64_entry_t idt64[256];
static idt64_ptr_t idt64p;

extern void isr128_64(void);
extern void isr_hang_64(void);
extern void isr0_64(void);
extern void isr1_64(void);
extern void isr2_64(void);
extern void isr3_64(void);
extern void isr4_64(void);
extern void isr5_64(void);
extern void isr6_64(void);
extern void isr7_64(void);
extern void isr8_64(void);
extern void isr9_64(void);
extern void isr10_64(void);
extern void isr11_64(void);
extern void isr12_64(void);
extern void isr13_64(void);
extern void isr14_64(void);
extern void isr15_64(void);
extern void isr16_64(void);
extern void isr17_64(void);
extern void isr18_64(void);
extern void isr19_64(void);
extern void isr20_64(void);
extern void isr21_64(void);
extern void isr22_64(void);
extern void isr23_64(void);
extern void isr24_64(void);
extern void isr25_64(void);
extern void isr26_64(void);
extern void isr27_64(void);
extern void isr28_64(void);
extern void isr29_64(void);
extern void isr30_64(void);
extern void isr31_64(void);

static void idt64_set_gate(uint8_t num, uint64_t base, uint16_t sel, uint8_t flags){
  idt64[num].offset_low  = (uint16_t)(base & 0xFFFF);
  idt64[num].selector    = sel;
  idt64[num].ist         = 0;
  idt64[num].type_attr   = flags;
  idt64[num].offset_mid  = (uint16_t)((base >> 16) & 0xFFFF);
  idt64[num].offset_high = (uint32_t)((base >> 32) & 0xFFFFFFFF);
  idt64[num].zero        = 0;
}

void idt64_init(void){
  for(int i=0;i<256;i++){
    idt64_set_gate((uint8_t)i, (uint64_t)isr_hang_64, 0x08, 0x8E);
  }

  idt64_set_gate(0,  (uint64_t)isr0_64,  0x08, 0x8E);
  idt64_set_gate(1,  (uint64_t)isr1_64,  0x08, 0x8E);
  idt64_set_gate(2,  (uint64_t)isr2_64,  0x08, 0x8E);
  idt64_set_gate(3,  (uint64_t)isr3_64,  0x08, 0x8E);
  idt64_set_gate(4,  (uint64_t)isr4_64,  0x08, 0x8E);
  idt64_set_gate(5,  (uint64_t)isr5_64,  0x08, 0x8E);
  idt64_set_gate(6,  (uint64_t)isr6_64,  0x08, 0x8E);
  idt64_set_gate(7,  (uint64_t)isr7_64,  0x08, 0x8E);
  idt64_set_gate(8,  (uint64_t)isr8_64,  0x08, 0x8E);
  idt64_set_gate(9,  (uint64_t)isr9_64,  0x08, 0x8E);
  idt64_set_gate(10, (uint64_t)isr10_64, 0x08, 0x8E);
  idt64_set_gate(11, (uint64_t)isr11_64, 0x08, 0x8E);
  idt64_set_gate(12, (uint64_t)isr12_64, 0x08, 0x8E);
  idt64_set_gate(13, (uint64_t)isr13_64, 0x08, 0x8E);
  idt64_set_gate(14, (uint64_t)isr14_64, 0x08, 0x8E);
  idt64_set_gate(15, (uint64_t)isr15_64, 0x08, 0x8E);
  idt64_set_gate(16, (uint64_t)isr16_64, 0x08, 0x8E);
  idt64_set_gate(17, (uint64_t)isr17_64, 0x08, 0x8E);
  idt64_set_gate(18, (uint64_t)isr18_64, 0x08, 0x8E);
  idt64_set_gate(19, (uint64_t)isr19_64, 0x08, 0x8E);
  idt64_set_gate(20, (uint64_t)isr20_64, 0x08, 0x8E);
  idt64_set_gate(21, (uint64_t)isr21_64, 0x08, 0x8E);
  idt64_set_gate(22, (uint64_t)isr22_64, 0x08, 0x8E);
  idt64_set_gate(23, (uint64_t)isr23_64, 0x08, 0x8E);
  idt64_set_gate(24, (uint64_t)isr24_64, 0x08, 0x8E);
  idt64_set_gate(25, (uint64_t)isr25_64, 0x08, 0x8E);
  idt64_set_gate(26, (uint64_t)isr26_64, 0x08, 0x8E);
  idt64_set_gate(27, (uint64_t)isr27_64, 0x08, 0x8E);
  idt64_set_gate(28, (uint64_t)isr28_64, 0x08, 0x8E);
  idt64_set_gate(29, (uint64_t)isr29_64, 0x08, 0x8E);
  idt64_set_gate(30, (uint64_t)isr30_64, 0x08, 0x8E);
  idt64_set_gate(31, (uint64_t)isr31_64, 0x08, 0x8E);

  idt64_set_gate(128, (uint64_t)isr128_64, 0x08, 0xEE);

  idt64p.limit = (uint16_t)(sizeof(idt64) - 1);
  idt64p.base = (uint64_t)&idt64;

  __asm__ volatile("lidt %0" : : "m"(idt64p));
}
