BITS 64

GLOBAL isr128_64
GLOBAL isr_hang_64
GLOBAL isr0_64
GLOBAL isr1_64
GLOBAL isr2_64
GLOBAL isr3_64
GLOBAL isr4_64
GLOBAL isr5_64
GLOBAL isr6_64
GLOBAL isr7_64
GLOBAL isr8_64
GLOBAL isr9_64
GLOBAL isr10_64
GLOBAL isr11_64
GLOBAL isr12_64
GLOBAL isr13_64
GLOBAL isr14_64
GLOBAL isr15_64
GLOBAL isr16_64
GLOBAL isr17_64
GLOBAL isr18_64
GLOBAL isr19_64
GLOBAL isr20_64
GLOBAL isr21_64
GLOBAL isr22_64
GLOBAL isr23_64
GLOBAL isr24_64
GLOBAL isr25_64
GLOBAL isr26_64
GLOBAL isr27_64
GLOBAL isr28_64
GLOBAL isr29_64
GLOBAL isr30_64
GLOBAL isr31_64
EXTERN isr80_handler64
EXTERN isr_exception_handler64

SECTION .text
isr_hang_64:
    cli
.hang:
    hlt
    jmp .hang

%macro EXC_STUB 1
isr%1_64:
    mov rdi, %1
    jmp isr_exception_common
%endmacro

EXC_STUB 0
EXC_STUB 1
EXC_STUB 2
EXC_STUB 3
EXC_STUB 4
EXC_STUB 5
EXC_STUB 6
EXC_STUB 7
EXC_STUB 8
EXC_STUB 9
EXC_STUB 10
EXC_STUB 11
EXC_STUB 12
EXC_STUB 13
EXC_STUB 14
EXC_STUB 15
EXC_STUB 16
EXC_STUB 17
EXC_STUB 18
EXC_STUB 19
EXC_STUB 20
EXC_STUB 21
EXC_STUB 22
EXC_STUB 23
EXC_STUB 24
EXC_STUB 25
EXC_STUB 26
EXC_STUB 27
EXC_STUB 28
EXC_STUB 29
EXC_STUB 30
EXC_STUB 31

isr_exception_common:
    mov rax, rsp
    and rsp, -16
    call isr_exception_handler64
    mov rsp, rax
    cli
.exc_hang:
    hlt
    jmp .exc_hang

isr128_64:
    push r15
    push r14
    push r13
    push r12
    push r11
    push r10
    push r9
    push r8
    push rbp
    push rdi
    push rsi
    push rdx
    push rcx
    push rbx
    push rax

    mov rdi, rsp
    call isr80_handler64
    mov [rsp], rax

    pop rax
    pop rbx
    pop rcx
    pop rdx
    pop rsi
    pop rdi
    pop rbp
    pop r8
    pop r9
    pop r10
    pop r11
    pop r12
    pop r13
    pop r14
    pop r15

    iretq
