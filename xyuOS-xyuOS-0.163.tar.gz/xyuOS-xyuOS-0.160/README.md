# xyuOS

## x86_64 stage (in progress)

Added separate 64-bit boot pipeline (does not replace current 32-bit build yet).

- Build 64-bit image: `make all64`
- Run 64-bit image: `make run64`

Current 64-bit stage includes:
- Multiboot2 64-bit boot path
- Long mode enable
- Minimal 64-bit kernel entry (`kernel64_main`)
- IDT64 initialization
- 64-bit `int 0x80` syscall path test
- ELF64 parser + in-kernel embedded ELF64 runner demo (ring0)
- `int 0x80` gate is user-callable (DPL3-ready)
- syscall return value path (`rax`) wired end-to-end
- initial ring3 switch (`iretq`) + user stub calling `int 0x80`
- embedded ELF64 entry now launched via ring3 transition path
- basic user process termination via syscall `exit` (number 60)
- ELF64 demo image now reconstructed through FS chunk files (`u64.0`, `u64.1`, ...)
- kernel64 now has generic ELF64 launch path from FS chunk prefix (`run_elf64_from_fs_prefix`)
- kernel64 boot now tries configured FS prefix first and seeds demo only if chunks are missing
- boot target prefix can be overridden via FS file `boot64.cfg` (first token)
- syscall base extended for libc path: `write(4)`, `yield(24)`, `ticks(39)`, `exit(60)`

### user64 runtime bootstrap

Cross-toolchain bootstrap (binutils + gcc for `x86_64-elf`):

```bash
cd xyuOS
make toolchain64
```

Prepare user sysroot (headers + crt0 + linker script):

```bash
make sysroot64
```

Bootstrap both:

```bash
make bootstrap64
```

By default, user64 build scripts try this toolchain first (`toolchain/x86_64-elf/bin/x86_64-elf-*`) and fallback to host `x86_64-linux-gnu-*` if missing.

New minimal user-space runtime files:
- `tools/user64/crt0.s`
- `tools/user64/sys.h`
- `tools/user64/sample_app.c`

Build sample C app into ELF chunks (`prefix.N`):

```bash
cd xyuOS
tools/user64/build_user64_chunks.sh tools/user64/sample_app.c u64 /tmp/u64_chunks
```

ASM-first path (default in Makefile):

```bash
tools/user64/build_user64_chunks.sh tools/user64/sample_asm_app.asm u64 /tmp/u64_chunks
```

Fast "vibe" ASM flow:

```bash
cd xyuOS
make new64-asm ASM_NAME=myprog
# edit: user64/myprog.asm
make run64-asm ASM_SRC=user64/myprog.asm
```

This outputs chunk files like `u64.0`, `u64.1`, ... (512-byte chunks) that match kernel64 FS chunk launch format.

One-command pipeline (build app -> update embedded include -> rebuild 64-bit ISO):

```bash
cd xyuOS
make prep64-user
```

Run with auto-prep:

```bash
make run64-user
```

No-kernel-rebuild user app refresh (runtime disk manifest path):

```bash
cd xyuOS
make inject64-user
make run64
```

Choose custom ASM source:

```bash
make run64-live USER64_SRC=tools/user64/my_program.asm
```

or one command:

```bash
make run64-live
```

Current 32-bit path remains default:
- Build: `make`
- Run: `make run`

Next 64-bit milestone:
- ELF64 user program loader
- user mode transition + syscall ABI

## Real C/ASM run workflow

`run` in xyuOS now executes real machine code from `.bin` files (no script interpreter).

### Native build inside xyuOS (no host tools)

You can now compile directly inside xyuOS:

- `asm prog.asm prog.bin` — assemble source to runnable `.bin` (hex payload file)
- `cc prog.c prog.bin` — compile C subset to runnable `.bin`
- `run prog.bin` — execute generated machine code

Minimal C subset for `cc`:
- `sys_puts("text\n");`
- `sys_puti(123);`
- `sys_cls();`

Minimal ASM subset for `asm`:
- `mov eax, imm32`
- `mov ebx, imm32|label`
- `int 0x80`
- `ret`
- labels: `name:`
- data: `db 'text',10,0`

### Kernel syscall ABI (`int 0x80`)

- `eax=1`, `ebx=char*` -> print string (`SYS_PUTS`)
- `eax=2`, `ebx=int` -> print integer (`SYS_PUTI`)
- `eax=3` -> clear console (`SYS_CLS`)

### Build real user programs on host

Use helper script:

```bash
cd xyuOS
tools/userprog/build_userprog.sh tools/userprog/sample.asm /tmp/sample.bin.txt
tools/userprog/build_userprog.sh tools/userprog/sample.c /tmp/sample_c.bin.txt
```

This creates a text file with hex bytes.

### Fast path (`loadbin`)

For built-in demos (no copy/paste):

```bash
loadbin demo-c myc.bin
run myc.bin

loadbin demo-asm myasm.bin
run myasm.bin
```

### Run inside xyuOS

1. In xyuOS shell: `new test.bin`
2. Open the file in editor and paste hex bytes from generated `*.bin.txt`
3. Save (`F2`)
4. Execute: `run test.bin`

Notes:
- Current file size limit is 512 bytes.
- `.c` / `.asm` files are source templates only; runtime executes `.bin`.

## Commands (2 words)

- `help` — list commands
- `ls` — list files
- `new a.bin` — create file
- `open a.bin` — open editor
- `asm a.asm b.bin` — assemble source
- `cc a.c b.bin` — compile source
- `save` / `F2` — save file
- `run a.bin` — execute binary
- `loadbin demo-c a.bin` — load demo
- `cat a.bin` — show text
- `rm a.bin` — remove file
- `clear` — clear console
- `cpu` — cpu vendor
- `uptime` — timer ticks
- `sys` — os info